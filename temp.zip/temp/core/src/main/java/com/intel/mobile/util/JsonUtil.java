package com.intel.mobile.util;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.servlet.jsp.PageContext;

import org.apache.commons.io.IOUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.intel.mobile.constants.IntelMobileConstants;
import com.intel.mobile.services.IntelConfigurationService;
import com.intel.mobile.vo.ProductDetailsVo;



public class JsonUtil {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ProductUtil.class);
	
	public static Map<String, Object> getNewProductListing(String product,
			int noOfProducts, Page currentPage, PageContext pageContext) {
		Map<String, Object> results = new HashMap<String, Object>();

		results.put("totalCount", null);
		results.put("results", "0");

		try {

			IntelConfigurationService intelConfig = IntelUtil
					.getIntelConfigService();

			String fastUrl = intelConfig.getFastSearchUrl();
			String language = intelConfig.getFastSearchAppId(); // Application
			// Id

			StringBuffer searchUrlString = new StringBuffer();
			searchUrlString.append("http://sp1004e9f5.guided.ss-omtrdc.net/?segment=json"); 
			
			/*		searchUrlString.append("&q5=true");
			searchUrlString.append("&q12=");*/

			LOGGER.info("searchUrlString :" + searchUrlString.toString());
			URL searchUrl = new URL(searchUrlString.toString());
			InputStream resultsStream = searchUrl.openStream();

			String jsonTxt = IOUtils.toString(resultsStream, "UTF-8");
			// LOGGER.info("---jsonTxt ---"+jsonTxt);
			jsonTxt=jsonTxt.substring(jsonTxt.indexOf("(")+1,jsonTxt.lastIndexOf(")"));
			JSONObject json = new JSONObject(jsonTxt);
			String totalResults = json.getJSONObject("customer-results").getJSONObject("query").getString("total-results");
			List<Map<String, String>> resultsList = new ArrayList<Map<String, String>>();
 
			if (!totalResults.equals("0")) {
				JSONArray resultset = json.getJSONObject("customer-results").getJSONObject("results").getJSONArray("result");

				for (int i = 0; i < resultset.length(); i++) {
					Map<String, String> item = new HashMap<String, String>();
					JSONObject fieldList = resultset.getJSONObject(i);
					Iterator<String> keys = fieldList.keys();
					while(keys.hasNext()){
					String key = keys.next();
				    String itemValue = fieldList.getString(key); 
					String hostname="http://localhost:4504";		
					// LOGGER.info("---itemvalue---"+itemValue);
					URL url = new URL("http://m-qa.intel.com"+ fieldList.getString(
							"url")+".html");
					String itemUrl = url.getPath();
                    //itemUrl = "http://localhost:4504" + itemUrl;

					item.put(
							"productName",
							parseNewFieldFromResponse(fieldList,
									
									"title"));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE,
							parseNewFieldFromResponse(fieldList,
									
									IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_WEIGHT,
							parseNewFieldFromResponse(fieldList,
									IntelMobileConstants.META_TAG_FILTER_WEIGHT));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_PROCESSOR,
							parseNewFieldFromResponse(fieldList,
								
									"processor"));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_COUNTRY,
							parseNewFieldFromResponse(fieldList,
								
									IntelMobileConstants.META_TAG_FILTER_COUNTRY));
					item.put(
							IntelMobileConstants.META_TAG_FILTER_CARRIER,
							parseNewFieldFromResponse(fieldList,
								
									IntelMobileConstants.META_TAG_FILTER_CARRIER));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_RAM,
							parseNewFieldFromResponse(fieldList,
									IntelMobileConstants.META_TAG_FILTER_RAM));
					item.put(
							IntelMobileConstants.META_TAG_FILTER_HARD_DRIVE_SIZE,
							parseNewFieldFromResponse(fieldList,
							
									IntelMobileConstants.META_TAG_FILTER_HARD_DRIVE_SIZE));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_SOCKET,
							parseNewFieldFromResponse(fieldList,
									IntelMobileConstants.META_TAG_FILTER_SOCKET));
					item.put(
							IntelMobileConstants.META_TAG_FILTER_FORM_FACTOR,
							parseNewFieldFromResponse(fieldList,
								
									IntelMobileConstants.META_TAG_FILTER_FORM_FACTOR));
					item.put(
							IntelMobileConstants.META_TAG_FILTER_CHIPSET,
							parseNewFieldFromResponse(fieldList,
							
									IntelMobileConstants.META_TAG_FILTER_CHIPSET));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_CAPACITY,
							parseNewFieldFromResponse(fieldList,
							
									IntelMobileConstants.META_TAG_FILTER_CAPACITY));
					item.put(
							IntelMobileConstants.META_TAG_FILTER_RAN_READ_WRITE,
							parseNewFieldFromResponse(fieldList,
								
									IntelMobileConstants.META_TAG_FILTER_RAN_READ_WRITE));
					item.put(
							IntelMobileConstants.META_TAG_FILTER_SEQ_READ_WRITE,
							parseNewFieldFromResponse(fieldList,
								
									IntelMobileConstants.META_TAG_FILTER_SEQ_READ_WRITE));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_PRICE,
							parseNewFieldFromResponse(fieldList,
									IntelMobileConstants.META_TAG_FILTER_PRICE));

					item.put(
							IntelMobileConstants.META_TAG_FILTER_PROPERTY_VALUE,
							parseNewFieldFromResponse(fieldList,
									IntelMobileConstants.META_TAG_FILTER_PROPERTY_VALUE));

					item.put(
							"manufacturer",
							parseNewFieldFromResponse(fieldList,
									
									"manufacturer"));
					
					item.put(
							"tagLine",
							parseNewFieldFromResponse(fieldList,
									
									IntelMobileConstants.META_TAG_FILTER_TAG_LINE));

					String productPath = parseNewFieldFromResponse(fieldList,
							"url");

					item.put("productPath", productPath);

					item.put(
							"pictureUrl",
							parseNewFieldFromResponse(fieldList,
								
									IntelMobileConstants.META_TAG_FILTER_PICTURE_URL));

					item.put("productId", productPath.substring(productPath
							.lastIndexOf("/") + 1));
					item.put("product", product);
					item.put("productUrl", itemUrl);

					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE,
							IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_PROCESSOR,
							IntelMobileConstants.META_TAG_FILTER_PROCESSOR);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_WEIGHT,
							IntelMobileConstants.META_TAG_FILTER_WEIGHT);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_RAM,
							IntelMobileConstants.META_TAG_FILTER_RAM);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_SOCKET,
							IntelMobileConstants.META_TAG_FILTER_SOCKET);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_CHIPSET,
							IntelMobileConstants.META_TAG_FILTER_CHIPSET);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_FORM_FACTOR,
							IntelMobileConstants.META_TAG_FILTER_FORM_FACTOR);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_CAPACITY,
							IntelMobileConstants.META_TAG_FILTER_CAPACITY);

					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_PROPERTY_VALUE,
							IntelMobileConstants.META_TAG_FILTER_PROPERTY_VALUE);

					pageContext
					.setAttribute(
							IntelMobileConstants.META_TAG_FILTER_RAN_READ_WRITE,
							IntelMobileConstants.META_TAG_FILTER_RAN_READ_WRITE);
					pageContext
					.setAttribute(
							IntelMobileConstants.META_TAG_FILTER_SEQ_READ_WRITE,
							IntelMobileConstants.META_TAG_FILTER_SEQ_READ_WRITE);
					pageContext
					.setAttribute(
							IntelMobileConstants.META_TAG_FILTER_HARD_DRIVE_SIZE,
							IntelMobileConstants.META_TAG_FILTER_HARD_DRIVE_SIZE);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_CARRIER,
							IntelMobileConstants.META_TAG_FILTER_CARRIER);
					pageContext.setAttribute(IntelMobileConstants.META_TAG_FILTER_COUNTRY,
							IntelMobileConstants.META_TAG_FILTER_COUNTRY);
					pageContext.setAttribute("product", product);

					// LOGGER.info("---item---"+item);
					
				}
					resultsList.add(item);
				
				}
			}
			results.put("totalCount", totalResults);
			results.put("results", resultsList);
		LOGGER.info("ResultList:"+ results);
		
		} catch (Exception e) {
			LOGGER.error("[getProductListing] Error Occurred - ", e);
		}

		return results;
	}
	
	private static String parseNewFieldFromResponse(JSONObject fieldList,String field) {
		String value = "";
		if(fieldList.has(field)){
			
			try {
				value=fieldList.get(field).toString();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			
			value="";
		}
		return value;
	}
}
