package com.intel.mobile.servlets;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Workspace;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.JcrTagManagerFactory;
import com.intel.mobile.constants.IntelMobileConstants;
import com.intel.mobile.util.RepoUtil;

/**
 * 
 * @author phegd1
 * 
 */

@Component(immediate = true, metatype = false, label = "Activated Pages Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/ActivatedPages") })
public class ActivatedPagesServlet extends SlingAllMethodsServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ActivatedPagesServlet.class);

	@Reference
	private SlingRepository repository;

	@Reference
	private JcrTagManagerFactory jcrTagManagerFactory;

	private Session jcrSession;

	@Override
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		OutputStream out = response.getOutputStream();
		
		String exportUrl = IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH;
		/*String paramLocale = request.getParameter("locale");
		String[] localeArray = { "EN","US" };
		if (null == paramLocale) {
			exportUrl = exportUrl + "us/en/%";
		} else {
			paramLocale = paramLocale.toLowerCase();
			localeArray = paramLocale.split("_");
			exportUrl = exportUrl + localeArray[1] + "/" + localeArray[0]
					+ "/%";
		}*/

		// String downloadOption=request.getParameter("downloadOption");
		// TreeMap<String, ProductsBean[]> productsMap=new TreeMap<String,
		// ProductsBean[]>();
		
		try {
			HSSFWorkbook wb = new HSSFWorkbook();
			long startTime = System.currentTimeMillis();
			jcrSession = RepoUtil.login(repository);
			Workspace workspace = jcrSession.getWorkspace();
			QueryManager queryManager = workspace.getQueryManager();
			Node intelRootNode = jcrSession.getNode(IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH);
			NodeIterator rootNodeIterator = intelRootNode.getNodes();
			while(rootNodeIterator.hasNext()){
				Node countryNode = rootNodeIterator.nextNode();
				if(countryNode.getName().equals("jcr:content") || countryNode.getName().startsWith("xe") || countryNode.getName().startsWith("xa") || countryNode.getName().length()!=2)
					continue;
				NodeIterator countryNodeIterator = countryNode.getNodes();
				HSSFSheet sheet = wb.createSheet(countryNode.getName().toUpperCase());
				while(countryNodeIterator.hasNext()){
					Node localeNode = countryNodeIterator.nextNode();
					if(localeNode.getName().equals("jcr:content") || localeNode.getName().length()!=2)
						continue;
					exportUrl=IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH+"/"+countryNode.getName()+"/"+localeNode.getName()+"/%";
					String queryString = "select * from nt:base where jcr:path like '"
							+ exportUrl + "' and cq:lastReplicationAction= 'Activate'";
					Query query = queryManager.createQuery(queryString, Query.SQL);
					QueryResult result = query.execute();
					NodeIterator it = result.getNodes();
					Node tempNode = null;
					
					sheet.setAutobreaks(true);
					int rownum = 0;
					int cellnum = 0;
					HSSFRow row = sheet.createRow(rownum++);
					HSSFCell cell = row.createCell(cellnum++);
					HSSFCellStyle style = wb.createCellStyle();
					style.setAlignment(style.ALIGN_LEFT);
					style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
					style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
					HSSFFont font = wb.createFont();
					font.setColor(HSSFColor.WHITE.index);
					font.setBoldweight(font.BOLDWEIGHT_BOLD);
					style.setFont(font);
					cell.setCellStyle(style);
					cell.setCellValue(countryNode.getName().toUpperCase() + " Activated Pages");
					cellnum = 0;
					row = sheet.createRow(rownum++);
					cell = row.createCell(cellnum++);
					cell.setCellStyle(style);
					cell.setCellValue("Path");
					cell = row.createCell(cellnum++);
					cell.setCellStyle(style);
					cell.setCellValue("Title");
					cell = row.createCell(cellnum++);
					cell.setCellStyle(style);
					cell.setCellValue("Name");
					cell = row.createCell(cellnum++);
					cell.setCellStyle(style);
					cell.setCellValue("Create Date");
					cell = row.createCell(cellnum++);
					cell.setCellStyle(style);
					cell.setCellValue("Modified Date");
					cell = row.createCell(cellnum++);
					cell.setCellStyle(style);
					cell.setCellValue("Shop Returned Data(Yes/No)");
					
					String domainName = request.getServerName();
					URL url;
					// String
					// protocol=request.getProtocol().split("/").length>1?request.getProtocol().split("/")[0]:request.getProtocol();
					while (it.hasNext()){
						cellnum = 0;
						tempNode = it.nextNode();
						row = sheet.createRow(rownum++);
						cell = row.createCell(cellnum++);
						cell.setCellValue("http://" + domainName + tempNode.getParent().getPath() + ".html");
						cell = row.createCell(cellnum++);
						cell.setCellValue(tempNode.hasProperty("jcr:title")?tempNode.getProperty("jcr:title").getString():"");
						cell = row.createCell(cellnum++);
						cell.setCellValue(tempNode.getParent().getName());
						cell = row.createCell(cellnum++);
						cell.setCellValue(tempNode.hasProperty("jcr:created")?tempNode.getProperty("jcr:created").getString():"");
						cell = row.createCell(cellnum++);
						cell.setCellValue(tempNode.hasProperty("cq:lastModified")?tempNode.getProperty("cq:lastModified").getString():"");
						cell = row.createCell(cellnum++);
						cell.setCellValue(tempNode.hasProperty("cq:template")?(tempNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/productdetails")?"YES":"NO"):"NO");
					}
					
				}
				sheet.setDefaultColumnWidth(50);
			}
			
			long endTime = System.currentTimeMillis();
			LOGGER.info("Excel Time: " + (endTime - startTime));
			String contentType = "application/vnd.ms-excel";
			response.setContentType(contentType);
			response.setHeader("Content-Disposition",
					"attachment;filename=Activated_Pages.xls");
			wb.write(out);
			out.flush();
			response.flushBuffer();

		} catch (PathNotFoundException pe) {
			LOGGER.info("An exception has occured: ", pe);
		} catch (RepositoryException re) {
			// TODO Auto-generated catch block
			LOGGER.info("An exception has occured: ", re);
		}
	}

}
