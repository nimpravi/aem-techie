package com.intel.mobile.test;

public class MyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServiceClass ob = new ServiceClass();
		ob.myCachedService();
	}

}
