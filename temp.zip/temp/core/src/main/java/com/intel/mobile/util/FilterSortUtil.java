package com.intel.mobile.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.jsp.PageContext;

import org.apache.commons.io.IOUtils;
import org.apache.felix.scr.annotations.Reference;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.api.SlingRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.commons.json.JSONException;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.intel.mobile.constants.IntelMobileConstants;

import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;





public class FilterSortUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductUtil.class);
	public static final String TAG_BASE_PATH = "intelmobile:";
	public static final String TAG_SECTION_SEARCH = "search";
	public static final String TAG_SECTION_PRODUCTS = "products";

	public static Map<String, Map<String, String>> getProductFilters(ResourceResolver resolver, Page page, String section, String category) {
		Map<String, Map<String, String>> filters = new LinkedHashMap<String, Map<String, String>>();
		List<String> filterItems = new ArrayList<String>();
		TagManager tagManager = resolver.adaptTo(TagManager.class);
		try {
			//String category = page.getName();
			String locale = IntelUtil.getLocaleWithoutChangingUK(page);
			String tagPath = "";
			if(section.equals(TAG_SECTION_SEARCH)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/filters";				
			} else if(section.equals(TAG_SECTION_PRODUCTS)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/" + category + "/filters";								
			}
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(">>>>Tag Path - " + tagPath);
			}
			Tag tag = tagManager.resolve(tagPath);
			if(tag != null) {
				Iterator<Tag> tagList = tag.listChildren();
				while(tagList.hasNext()) {
					Tag filterTag = (Tag) tagList.next();
					try {
						String filterTitle = filterTag.getTitle();
						String filterName = filterTag.getName();
						Map<String, String> subFilterMap = new LinkedHashMap<String, String>();
						Iterator<Tag> subFilterTagList = filterTag.listChildren();
						while(subFilterTagList.hasNext()) {
							Tag subFilterTag = (Tag)subFilterTagList.next();
							subFilterMap.put(subFilterTag.getName(), subFilterTag.getTitle());
						
						}
						if(!subFilterMap.isEmpty()){
							filters.put(filterName + "`" + filterTitle, subFilterMap);	
							filterItems.add(filterTitle);
						
						}															
						if(LOGGER.isDebugEnabled()) {
							LOGGER.debug("getProductFilters() - Filter Title - " + filterTitle + ", Sub Filters - " + subFilterMap);
						}
					} catch(Exception e) {
						LOGGER.error("getProductFilters() - Exception occured while processing tag for - " + filterTag.getTitle());
					}
				}				
			}			
		} catch(Exception e) {
			LOGGER.error("getProductFilters() - Exception occured - " + e);
		}
		return filters;		
	}
	
	public static String  getProductFilterItems(ResourceResolver resolver, Page page, String section, String category) {
		//Map<String, Map<String, String>> filters = new LinkedHashMap<String, Map<String, String>>();
		Map<String,String> filterItems = new LinkedHashMap<String,String>();
		TagManager tagManager = resolver.adaptTo(TagManager.class);
		String json="";
		JSONObject filterjson=new JSONObject();
	
		
		try {
			//String category = page.getName();
			String locale = IntelUtil.getLocaleWithoutChangingUK(page);
			String tagPath = "";
			if(section.equals(TAG_SECTION_SEARCH)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/filters";				
			} else if(section.equals(TAG_SECTION_PRODUCTS)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/" + category.toLowerCase() + "/filters";								
			}
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(">>>>Tag Path - " + tagPath);
			}
			Tag tag = tagManager.resolve(tagPath);
			if(tag != null) {
				Iterator<Tag> tagList = tag.listChildren();
				while(tagList.hasNext()) {
					Tag filterTag = (Tag) tagList.next();
					try {
						String filterTitle = filterTag.getTitle();
						String filterName = filterTag.getName();
						Map<String, String> subFilterMap = new LinkedHashMap<String, String>();
						Iterator<Tag> subFilterTagList = filterTag.listChildren();
						while(subFilterTagList.hasNext()) {
							Tag subFilterTag = (Tag)subFilterTagList.next();
							subFilterMap.put(subFilterTag.getName(), subFilterTag.getTitle());
						}
						
							//filters.put(filterName + "`" + filterTitle, subFilterMap);	
							filterItems.put(filterName,filterTitle);
						
							json = filterjson.put(filterName,filterTitle).toString();
							LOGGER.info("Filter Json:" + json);
							//Gson gson = new Gson();
						     // json = gson.toJson(filterItems);
						
						
						
																					
						if(LOGGER.isDebugEnabled()) {
							LOGGER.debug("getProductFilters() - Filter Title - " + filterTitle + ", Sub Filters - " + subFilterMap);
						}
					} catch(Exception e) {
						LOGGER.error("getProductFilters() - Exception occured while processing tag for - " + filterTag.getTitle());
					}
				}				
			}			
		} catch(Exception e) {
			LOGGER.error("getProductFilters() - Exception occured - " + e);
		}
		return json;		
	}
	
	public static void getProcessorSubFilterItems(ResourceResolver resolver, Page page, String section, String category,PageContext pageContext) {
		//Map<String, Map<String, String>> filters = new LinkedHashMap<String, Map<String, String>>();
		Map<String,String> filterItems = new LinkedHashMap<String,String>();
		TagManager tagManager = resolver.adaptTo(TagManager.class);
		String json="";
		JSONObject filterjson=new JSONObject();
		try {
			//String category = page.getName();
			String locale = IntelUtil.getLocaleWithoutChangingUK(page);
			String tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/" + category.toLowerCase() + "/filters"+"/filterprocessor";								
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(">>>>Tag Path - " + tagPath);
			}
			Tag tag = tagManager.resolve(tagPath);
			if(tag != null) {
				Iterator<Tag> tagList = tag.listChildren();
				while(tagList.hasNext()) {
					Tag filterTag = (Tag) tagList.next();
					String filterTitle = filterTag.getTitle();
					String filterName = filterTag.getName();
					filterItems.put(filterName,filterTitle);
					LOGGER.info("Filter Json:" + filterItems);
				}				
			}			
		} catch(Exception e) {
			LOGGER.error("getProductFilters() - Exception occured - " + e);
		}
		pageContext.setAttribute("processorMap", filterItems);
	}
	
	
	
	public static String  getProductFilterNames(ResourceResolver resolver, Page page, String section, String category) {
		//Map<String, Map<String, String>> filters = new LinkedHashMap<String, Map<String, String>>();
		Map<String,String> filterItems = new LinkedHashMap<String,String>();
		TagManager tagManager = resolver.adaptTo(TagManager.class);
		String json="";
		JSONObject filterjson=new JSONObject();
		try {
			//String category = page.getName();
			String locale = IntelUtil.getLocaleWithoutChangingUK(page);
			String tagPath = "";
			if(section.equals(TAG_SECTION_SEARCH)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/filters";				
			} else if(section.equals(TAG_SECTION_PRODUCTS)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/" + category.toLowerCase() + "/filters";								
			}
			if(LOGGER.isDebugEnabled()) {
				LOGGER.debug(">>>>Tag Path - " + tagPath);
			}
			Tag tag = tagManager.resolve(tagPath);
			if(tag != null) {
				Iterator<Tag> tagList = tag.listChildren();
				while(tagList.hasNext()) {
					Tag filterTag = (Tag) tagList.next();
					try {
						String filterTitle = filterTag.getTitle();
						String filterName = filterTag.getName();
						Map<String, String> subFilterMap = new LinkedHashMap<String, String>();
						Iterator<Tag> subFilterTagList = filterTag.listChildren();
						while(subFilterTagList.hasNext()) {
							Tag subFilterTag = (Tag)subFilterTagList.next();
							subFilterMap.put(subFilterTag.getName(), subFilterTag.getTitle());
						}
						
							//filters.put(filterName + "`" + filterTitle, subFilterMap);	
							filterItems.put(filterName,filterTitle);
						
							json = filterjson.put(filterTitle,filterName).toString();
							LOGGER.info("Filter Json:" + json);
							//Gson gson = new Gson();
						     // json = gson.toJson(filterItems);
						
						
						
																					
						if(LOGGER.isDebugEnabled()) {
							LOGGER.debug("getProductFilters() - Filter Title - " + filterTitle + ", Sub Filters - " + subFilterMap);
						}
					} catch(Exception e) {
						LOGGER.error("getProductFilters() - Exception occured while processing tag for - " + filterTag.getTitle());
					}
				}				
			}			
		} catch(Exception e) {
			LOGGER.error("getProductFilters() - Exception occured - " + e);
		}
		return json;		
	}	
	
	
	
	public static Map<String, String> getProductSortOptions(ResourceResolver resolver, Page page, String section, String category) {
		Map<String, String> sortoptions = new LinkedHashMap<String, String>();
		TagManager tagManager = resolver.adaptTo(TagManager.class);
		try {
			//String category = page.getName();
			String locale = IntelUtil.getLocaleWithoutChangingUK(page);
			String tagPath = "";
			if(section.equals(TAG_SECTION_SEARCH)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/sort";			
				if(LOGGER.isDebugEnabled()) {
					LOGGER.debug(">>>>Tag Path - " + tagPath);
				}
				Tag tag = tagManager.resolve(tagPath);
				if(tag!=null) {
					Iterator<Tag> tagList = tag.listChildren();
					while(tagList.hasNext()) {
						Tag sortTag = (Tag) tagList.next();
						String sortName = sortTag.getName();
						String sortTitle = sortTag.getTitle();	
						sortoptions.put(sortName+":ascending", sortTitle);
					}									
				}
			} else if(section.equals(TAG_SECTION_PRODUCTS)) {
				tagPath = TAG_BASE_PATH + locale 
						+ "/" + section + "/" + category.toLowerCase() + "/sort";					
				if(LOGGER.isDebugEnabled()) {
					LOGGER.debug(">>>>Tag Path - " + tagPath);
				}
				Tag tag = tagManager.resolve(tagPath);
				if(tag!=null) {
					Iterator<Tag> tagList = tag.listChildren();
					while(tagList.hasNext()) {
						Tag sortTag = (Tag) tagList.next();
						String sortName = sortTag.getName();
						String sortTitle = sortTag.getTitle();
						sortTitle = sortTitle.replaceAll(" ", "");
						Iterator<Tag> sortTagList = sortTag.listChildren();
						while(sortTagList.hasNext()) {
							try {							
								Tag sortoptionTag = (Tag)sortTagList.next();
								sortoptions.put(sortName + ":" + sortoptionTag.getName(), 
										sortoptionTag.getTitle());
								if(LOGGER.isDebugEnabled()) {
									LOGGER.debug("getProductFilters() - Sort Title - " 
											+ sortTitle + ", Sub Sort - " + sortoptionTag.getTitle());
								}
							} catch(Exception e) {
								LOGGER.error("getProductSortOptions() - Exception occured while processing tag for - " + sortName);
							}
						}
					}						
				}			
			}			

		} catch(Exception e) {
			LOGGER.error("getProductSortOptions() - Exception occured - " + e);
		}
		return sortoptions;		
	}	


	public static  Map<String, Map<String, String>> getnewFilters(Page page,Session jcrSession,String category) throws FileNotFoundException, IOException, RepositoryException, JSONException{


		//URL intelShopAPIUrl = new URL("http://search.intel.com/webhandlers/SearchWebHandler.ashx?q1=mobilecq&q2=en&q3=1&q5=true&q12=true&q10=localecode:en_US:exactphrase~reimaginesublevelcategory:Mobile^category^laptop:anyword&q23=:&q24=~");
		//InputStream in =  intelShopAPIUrl.openStream();


		//Node fileNode =   jcrSession.getNode("/content/usergenerated/intel/Motherboards.json/jcr:content");
		//InputStream in = fileNode.getProperty("jcr:data").getStream(); 

		String locale = IntelUtil.getLocaleWithoutChangingUK(page);
		String searchURL="http://search.intel.com/webhandlers/SearchWebHandler.ashx?";
		String q1="mobilecq";
		String q2="en";
		String q3="1";
		String q5="true";
		String q12="true";
		StringBuffer q10parts = new StringBuffer();
		q10parts.append("localecode:");
		q10parts.append(locale);
		q10parts.append(":exactphrase~reimaginesublevelcategory:Mobile^category^");
		q10parts.append(category);
		q10parts.append(":anyword&q23=:&q24=~");
		String q10=q10parts.toString();
		String fastUrl=searchURL+"q1="+ q1 +"&" + "q2=" +q2 +"&"+"q3="+q3 + "&" +"q5="+q5 + "&"+ "q12=" + q12 + "&" + "q10=" + q10;
		URL filterlistURL = new URL(fastUrl);
		InputStream in =  filterlistURL.openStream();
		String jsonTxt = IOUtils.toString(in, org.apache.commons.lang.CharEncoding.UTF_8);
		JSONObject jsonObject = new JSONObject(jsonTxt);
		LOGGER.info("Fast URL:" + fastUrl);
		Map<String, Map<String, String>> formattedfilters = new LinkedHashMap<String, Map<String, String>>();
		Map<String, Set<String>> filters = new LinkedHashMap<String, Set<String>>();
		HashSet<String> filtervalueSet = new HashSet<String>(); 
		//JSONObject jsonObject = (JSONObject) obj;
		JSONObject nav = (JSONObject) jsonObject.get("Navigators");
		JSONArray navList = (JSONArray) nav.get("NavigatorList");
		for (int i = 0; i < navList.length(); i++) {
			JSONObject modi = (JSONObject) navList.get(i);
			JSONArray modiList = (JSONArray) modi.get("ModifierList");
			String navi = (String) modi.get("NavigatorName");
			if (navi.equalsIgnoreCase("reimaginesublevelcategory")) {
				for (int j = 0; j < modiList.length(); j++) {
					JSONObject modicountNValue = (JSONObject) modiList.get(j);
					String valueset = (String) modicountNValue.get("ModifierValue");
					String[] parts = valueset.split("\\^");
					if(parts.length>1){
						if(filters.containsKey(parts[1]))
							filtervalueSet=(HashSet<String>) filters.get(parts[1]);
						else
							filtervalueSet = new HashSet<String>(); 
						filtervalueSet.add(parts[2]);

						List<String> filterlist=new ArrayList<String>();
						filterlist=getFilterList(category);
						if(filterlist.contains(parts[1].replaceAll(" ","").toLowerCase()))
							filters.put(parts[1], filtervalueSet);

					}
				}

				System.out.println("Final filter list"+filters);
				formattedfilters= getformattedFilterList(filters);
				System.out.println("Formatted filters:" + formattedfilters);
			}

		}
		return formattedfilters;

	} 

	private static Map<String, Map<String, String>> getformattedFilterList(
			Map<String, Set<String>> filterlist) {
		Map<String, Map<String, String>> filters = new LinkedHashMap<String, Map<String, String>>();

		Set<String> subfilterSet = new HashSet<String>(); 
		Iterator<Map.Entry<String, Set<String>>> iter = filterlist.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry<String, Set<String>> mEntry = iter.next();
			String filterkey=mEntry.getKey();
			String newkey= filterkey.toLowerCase().replaceAll(" ","") +"`" +filterkey.replaceAll(" ","") ;
			subfilterSet=mEntry.getValue();		
			Iterator itr = subfilterSet.iterator();
			//System.out.println("Sub Filter values:"+ subfilterSet);
			Map<String,String> subfiltermap = new HashMap<String,String>();

			while(itr.hasNext()){

				String setelements= itr.next().toString();
				String subfilterkey=setelements.toLowerCase();
				String subfiltervalue=setelements;
				subfiltermap.put(subfilterkey, subfiltervalue);

			}
			// System.out.println("SubFilterMap:"+subfiltermap );
			filters.put(newkey, subfiltermap);

		}

		return filters;	
	}

	public static List<String> getFilterList(String category){

		List<String> filterlist = new ArrayList<String> ();



		if(category.equals("ultrabooks")){

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE);

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_WEIGHT);

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_PROCESSOR);

			filterlist.add("price");
			filterlist.add("brand");
			filterlist.add("os");

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_RAM);
			filterlist.add("ssd");

		}else if(category.equals("tablets")){

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE);

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_WEIGHT);

			filterlist.add("os");

		}else if(category.equals("smartphones")){

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_COUNTRY);


		}else if(category.equals("laptops")){

			filterlist.add("price");
			filterlist.add("brand");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE);
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_WEIGHT);
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_PROCESSOR);
			filterlist.add("os");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_RAM);
			filterlist.add("ssd");
		}else if(category.equals("allinones")){

			filterlist.add("price");
			filterlist.add("brand");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE);
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_PROCESSOR);
			filterlist.add("os");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_RAM);
			filterlist.add("harddrive");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_HARD_DRIVE_SIZE);

		}else if(category.equals("desktop")){
			filterlist.add("price");
			filterlist.add("brand");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_PROCESSOR);
			filterlist.add("os");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_RAM);
			filterlist.add("harddrive");
			filterlist.add("ssd");

		}else if(category.equals("motherboards")){


			filterlist.add(IntelMobileConstants.META_TAG_FILTER_SOCKET);
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_FORM_FACTOR);

			filterlist.add(IntelMobileConstants.META_TAG_FILTER_CHIPSET);
			filterlist.add("integratedgraphics");


		}

		else if(category.equals("ssd")){
			filterlist.add("series");
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_CAPACITY);
			filterlist.add(IntelMobileConstants.META_TAG_FILTER_FORM_FACTOR);
			filterlist.add("interface");		
		}

		return filterlist;

	}



}
