package com.intel.mobile.services.impl;

import java.security.AccessControlException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RangeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import com.intel.mobile.constants.IntelMobileConstants;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.jcr.resource.JcrResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.intel.mobile.sync.ProductsSynchronizer;
import com.intel.mobile.util.IntelUtil;
import com.intel.mobile.vo.MonitorDetailsVO;
import com.intel.mobile.vo.ProductVO;
import com.day.cq.tagging.InvalidTagFormatException;
import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import org.apache.sling.api.resource.ResourceResolver;
/**
 * @author ggoswa
 *
 */


public class ShopNodeMonitorServiceImpl {
	private static final Logger log = LoggerFactory.getLogger(ShopNodeMonitorServiceImpl.class);	

	public Map<String,List<MonitorDetailsVO>>  shopMonitor(Session jcrSession,String window,ResourceResolver resourceResolver) throws AccessControlException, InvalidTagFormatException{
		TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
		log.info("TagManager:"+ tagManager);
		long startTime = System.currentTimeMillis();
		log.info("Products Monitoring Started at " + System.currentTimeMillis());
		List<MonitorDetailsVO> monitorList = new ArrayList<MonitorDetailsVO>();
		Map<String,List<MonitorDetailsVO>> products = new HashMap<String, List<MonitorDetailsVO>>();
		try{	

			if(tagManager.resolve(IntelMobileConstants.SHOP_MONITOR_TAG)== null ){
				log.info("Inside root node");
				Tag productCategoryTag = tagManager.createTag(IntelMobileConstants.SHOP_MONITOR_TAG, "Products Count", "Tag to store Product count");
				log.info("Tag created:"+ productCategoryTag.getTitle());

			}
			Node intelRootNode = jcrSession.getNode(IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH);
			NodeIterator rootNodeIterator = intelRootNode.getNodes();
			while(rootNodeIterator.hasNext()){
				Node countryNode = rootNodeIterator.nextNode();
				NodeIterator countryNodeIterator = countryNode.getNodes();
				while(countryNodeIterator.hasNext()){
					Node localeNode = countryNodeIterator.nextNode();
					log.info("Inside monitor node");
					log.info("Country node:"+ countryNode.getName());
					if(!(countryNode.getName().equals("xa")||countryNode.getName().equals("xe")) ){
						log.info("Country node inside :"+ countryNode.getName());
						if(localeNode.hasNode("jcr:content/locale")){
							Node localeInfoNode =  localeNode.getNode("jcr:content/locale");
							if(localeInfoNode.hasProperty("localeid") && localeInfoNode.hasProperty("language")){
								String localeId = localeInfoNode.getProperty("localeid").getString();
								String localeLang = localeInfoNode.getProperty("language").getString();
								String localekey =localeLang + "("+localeId + ")";

								if(tagManager.resolve(IntelMobileConstants.SHOP_MONITOR_TAG+ "/" + localeLang)== null ){
									Tag localeTag = tagManager.createTag(IntelMobileConstants.SHOP_MONITOR_TAG+"/"+ localeLang, localeLang.toUpperCase(), "Tag to store Product count");

								}			
								if(tagManager.resolve(IntelMobileConstants.SHOP_MONITOR_TAG+ "/" + localeLang + "/" + "products")==null){

									Tag productsTag = tagManager.createTag(IntelMobileConstants.SHOP_MONITOR_TAG +"/"+ localeLang + "/" + "products","Products","Products Node");
								}


								String productstagPath = IntelMobileConstants.SHOP_MONITOR_TAG+"/"+ localeLang + "/"+  "products";
								Node productsrootnode = jcrSession.getNode(localeNode.getPath());
								if(localeNode.hasNode(IntelMobileConstants.NODE_NAME_PRODUCTS)){
									Node  productsNode = productsrootnode.getNode(IntelMobileConstants.NODE_NAME_PRODUCTS);
									monitorList=monitornodeUpdate(jcrSession,productsNode,productstagPath,window,tagManager);

									if(!monitorList.isEmpty())
										products.put(localekey,monitorList);
									log.info("Products Monitored:"+monitorList);
									log.info("Completed Product Monitoring for locale - " + localeId);


								}


							}
						}	
					}
				}
			}


		}catch (PathNotFoundException e) {
			log.error("PathNotFoundException :"+e.getMessage());

		} catch (RepositoryException e) {
			log.error("RepositoryException :"+e.getMessage());

		} catch (Exception e) {
			log.error("Exception :"+e.getMessage());


		}finally{

			long completedTime = System.currentTimeMillis();			
			long totalTime = (completedTime - startTime)/1000;
			log.info("Products Monitoring Completed at " + completedTime + "--- " + Long.toString(totalTime));
			log.info("Total time taken for monitoring - " + totalTime);

		}

		return products;

	}



	public List<MonitorDetailsVO> monitornodeUpdate( Session jcrSession,Node productsNode, String monitorproductstagPath,String window,TagManager tagManager)	{


		List<MonitorDetailsVO> monitorList = new ArrayList<MonitorDetailsVO>();
		try{
			NodeIterator productsNodeiterator =  productsNode.getNodes();
			while (productsNodeiterator.hasNext()){
				Node categoryNode= productsNodeiterator.nextNode();
				NodeIterator productsIterator = categoryNode.getNodes();
				Long iteratorsize = productsIterator.getSize()-1;
				if(!categoryNode.getName().equals("jcr:content")){
					if(tagManager.resolve(monitorproductstagPath + "/" + categoryNode.getName())!=null){
						log.info("Tags exists");
						//log.info("Monitor Tag Path:"+monitorproductstagPath + "/" + categoryNode.getName() + "/"+ Long.toString(productsIterator.getSize()));
						Tag monitorcategoryTag= tagManager.resolve(monitorproductstagPath + "/" + categoryNode.getName() + "/" + "Products count");
						log.info("Monitor Tag Name:"+ monitorcategoryTag.getName());
						String count=monitorcategoryTag.getTitle();
						log.info("Count:" + count);
						Long productsCount=(long) Integer.parseInt(count);
						if(Math.abs(iteratorsize - productsCount) > Integer.parseInt(window))  
						{
							log.info("Inside Monitor VO");
							long change =(iteratorsize - productsCount);
							MonitorDetailsVO monitordetailsvo = new MonitorDetailsVO();
							monitordetailsvo.setCategory(categoryNode.getName());
							monitordetailsvo.setInitial_count(productsCount); 
							monitordetailsvo.setFinal_count(iteratorsize);
							monitordetailsvo.setPercentage_change(change);
							monitorList.add(monitordetailsvo);
						}
						//log.info("Not Exceeded Count");
						tagManager.deleteTag(monitorcategoryTag);
						tagManager.createTag(monitorproductstagPath+ "/" + categoryNode.getName() + "/" + "Products count",Long.toString(iteratorsize),"Count for the category: " + categoryNode.getName());



					}


					else{
						//Tag categoriesTag = IntelUtil.createNode(monitorproductsrootNode,categoryNode.getName(),IntelMobileConstants.PRIMARY_TYPE_CQ_PAGE);

						Tag categoriesTag  = tagManager.createTag(monitorproductstagPath+ "/" + categoryNode.getName(), categoryNode.getName().toLowerCase(), "Product category name");
						Tag productcountTag = tagManager.createTag(monitorproductstagPath+ "/" + categoryNode.getName() + "/" + "Products count" ,Long.toString(iteratorsize),"Count for the category: "+ categoryNode.getName());


					}

				}	

			}
			jcrSession.save();

		}catch (PathNotFoundException e) {
			log.error("PathNotFoundException :"+e.getMessage());

		} catch (RepositoryException e) {
			log.error("RepositoryException :"+e.getMessage());

		} catch (Exception e) {
			log.error("Exception :"+e.getMessage());


		}
		return monitorList;	


	}





}				











