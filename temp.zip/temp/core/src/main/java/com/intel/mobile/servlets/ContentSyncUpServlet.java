package com.intel.mobile.servlets;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.Workspace;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletException;


import org.apache.axis.encoding.Base64;
import org.apache.commons.httpclient.HttpClient;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jsoup.Connection;
import org.jsoup.Connection.Method;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.day.cq.tagging.JcrTagManagerFactory;
import com.intel.mobile.util.RepoUtil;

/**
 * 
 * @author ggoswa
 *
 */


@Component(immediate = true, metatype = false, label = "Content Audit Sync Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/ContentAuditSync") })


public class ContentSyncUpServlet extends SlingAllMethodsServlet{

	private static final Logger LOGGER = LoggerFactory.getLogger(ContentSyncUpServlet.class);

	@Reference
	private SlingRepository repository;	

	private Session jcrSession;
	Document doc;

	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		//LOGGER.info("ContentSync:-----------");
		OutputStream out = response.getOutputStream();
		String paramLocale = request.getParameter("locale").toLowerCase();
		if(null ==paramLocale)
			paramLocale="en_us";
		String[] localeArray=paramLocale.split("_");
		String downloadOption=request.getParameter("downloadOption");
		String exportUrl="/content/intelmobile/"+localeArray[1]+"/"+localeArray[0]+"/%";
		String queryString="select * from nt:base where jcr:path like '"+exportUrl+"' and cq:lastReplicationAction= 'Activate'";
		try {
			jcrSession = RepoUtil.login(repository);
			Workspace workspace=jcrSession.getWorkspace();
			QueryManager queryManager = workspace.getQueryManager();
			Query query = queryManager.createQuery(queryString, Query.SQL);
			// execute query
			QueryResult result = query.execute();
			NodeIterator it = result.getNodes();
			NodeIterator init = result.getNodes();
			NodeIterator linkin = result.getNodes(); 
			int count=0;
			Node tempNode=null;
			String category="";
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("Intel-Content Audit");
			sheet.setAutobreaks(true);
			int rownum=1;
			int cellnum=0;
			int rowIndex=2;
			HSSFRow firstrow  = sheet.createRow(0);
			HSSFCell firstcell = firstrow.createCell(0);
			firstcell.setCellValue("M.INTEL.COM - CONTENT AUDIT");
			HSSFRow row  = sheet.createRow(rownum++);
			HSSFCell cell = row.createCell(cellnum++);
			HSSFCellStyle style=wb.createCellStyle();
			style.setAlignment(style.ALIGN_LEFT);
			style.setFillForegroundColor(HSSFColor.SKY_BLUE.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			HSSFFont font = wb.createFont();
			font.setColor(HSSFColor.WHITE.index);
			font.setBoldweight((short) 16);
			style.setFont(font);
			cell.setCellStyle(style);
			cell.setCellValue("ID#"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("DOC OWNER"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("DOC TITLE"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("LEVEL 2 	SUB_TOPIC"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("LEVEL 3	SUB_TOPIC"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("CONTENT TYPE"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("DESC"); 
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("URL");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("HTML PAGE TITLE");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("META DESCRIPTIONS");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("META KEYWORDS");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("OPTIMIZED");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("TYPE");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("AUTHOR");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("LAST UPDATED");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("HEIRARCHY");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("SOCIAL SHARING");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("CTA?");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("HIGH MED LOW");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("COMMENTS");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("LINKS OUT");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("LINKS IN");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("RELATED");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("ATTACHED FILE");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("AVAILABILITY");
			cell=row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("GA TAGGING");

			long startTime=System.currentTimeMillis();

			if(downloadOption.equals("actualData"))
			{
				int j=0;

				while(init.hasNext()){
					Node currNode=init.nextNode();
					if(currNode!=null && currNode.getPath().contains("jcr:content")){
						   LOGGER.info("Path:"+ currNode.getPath());
							currNode.setProperty("inboundlinks",0);

						
					}
					jcrSession.save();
				}


				while(it.hasNext())
				{
					j++;
					cellnum=0;
					tempNode=it.nextNode();
					if(tempNode!=null)
					{ 


						row = sheet.createRow(rownum++);
						cell=row.createCell(cellnum++);
						cell.setCellValue(j);
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue(tempNode.getParent().getName());
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						if(tempNode.hasProperty("jcr:description"))
							cell.setCellValue(tempNode.getProperty("jcr:description").getString());
						cell=row.createCell(cellnum++);
						cell.setCellValue("http://" + request.getServerName() + ":" + request.getServerPort() + tempNode.getParent().getPath() + ".html");
						cell=row.createCell(cellnum++);
						if(tempNode.hasProperty("jcr:title"))
							cell.setCellValue(tempNode.getProperty("jcr:title").getString());
						cell=row.createCell(cellnum++);
						if(tempNode.hasProperty("jcr:description"))
							cell.setCellValue( tempNode.getProperty("jcr:description").getString());
						cell=row.createCell(cellnum++);

						if(tempNode.hasProperty("cq:tags")){
							Value[] keywords =tempNode.getProperty("cq:tags").getValues();
							StringBuffer tags= new StringBuffer(); 
							String modval="";
							int i=0;
							for(Value val: keywords){
								String value= val.getString();
								if(value.indexOf("/")!=-1)
									modval = value.substring(value.lastIndexOf("/")+1);
								LOGGER.info("Keyword:"+ val.getString());
								tags.append(modval);
								i++;
								if(i<keywords.length){
									tags.append(",");

								}
							}
							LOGGER.info("Tagkeyword:"+ tags);
							cell.setCellValue(tags.toString());
						}
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						if(tempNode.getParent().hasProperty("jcr:createdBy"))
							cell.setCellValue(tempNode.getParent().getProperty("jcr:createdBy").getString());
						cell=row.createCell(cellnum++);
						if(tempNode.hasProperty("cq:lastModified"))
							cell.setCellValue(tempNode.getProperty("cq:lastModified").getString());
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);




						if(tempNode.hasNode("showcase")){
							Node showcaseNode = tempNode.getNode("showcase");
							if(showcaseNode.hasProperty("displaysocial")){
								if(showcaseNode.getProperty("displaysocial").getString().equals("yes")){
									cell.setCellValue("Yes"); 
								}
								else
									cell.setCellValue("No"); 
							}
							else
								cell.setCellValue("No"); 
						}
						else if(tempNode.hasProperty("cq:template")){ 

							if(tempNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/productdetails")||tempNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/productdetailscms")||tempNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/article")){

								cell.setCellValue("Yes");
							}


							else if (tempNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/ultrabooktemplate")){

								if(tempNode.hasNode("contentPar")){
									Node parsysNode= tempNode.getNode("contentPar");
									if(parsysNode.hasNode("campaignheader")){

										Node campaignNode= parsysNode.getNode("campaignheader");
										if(campaignNode.hasProperty("displaysocial")){
											if(campaignNode.getProperty("displaysocial").getString().equals("yes")){ 

												cell.setCellValue("Yes"); 

											} 
											else 
												cell.setCellValue("No");	

										}

									}


								}
							}
							else{

								cell.setCellValue("No");	
							}	

						}
						else{
							cell.setCellValue("No");  
						}
						cell=row.createCell(cellnum++);  
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");

						cell=row.createCell(cellnum++);

						String url ="http://m.intel.com"  + tempNode.getParent().getPath() + ".html";

						//LOGGER.info("Connection Url:"+ url);



						int statusCode=Jsoup.connect(url).response().statusCode();
						LOGGER.info("New Status Code:" + Jsoup.connect(url).response().statusMessage() );

						try{
							doc = Jsoup.connect(url).timeout(1000000000).get();
							String title = doc.title();
							System.out.println("title : " + title);


							// get all links
							Elements links = doc.select("a[href]");
							for (Element link : links) {

								// get the value from href attribute

								String hreflink = link.attr("href");
								//LOGGER.info("\nlink : " + link.attr("href"));
								if(hreflink.startsWith("/") && hreflink.length()>1){
									if(jcrSession.nodeExists("/content/intelmobile"+ hreflink.replaceAll(".html",""))){ 
										//LOGGER.info("HREF link:"+hreflink.replaceAll(".html","")) ;
										Node currentNode = jcrSession.getNode("/content/intelmobile" + hreflink.replaceAll(".html","")+ "/jcr:content");
										if(currentNode.hasProperty("inboundlinks")){

											int  incount = Integer.parseInt(currentNode.getProperty("inboundlinks").getString());
											incount++;
											currentNode.setProperty("inboundlinks", incount);


										}
										else
											currentNode.setProperty("inboundlinks",1);
										jcrSession.save();
									}
									//LOGGER.info("text : " + link.text());
									//LOGGER.info("No of links:" + links.size());
								}
							}
							cell.setCellValue(links.size());




						}

						catch(IOException ioe)
						{
							LOGGER.error("Content Sync IO Exception:",ioe);
						}


						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");
						cell=row.createCell(cellnum++);
						cell.setCellValue("");

					}

				} 

				while(linkin.hasNext()){
					Node currNode=linkin.nextNode();
					if(currNode!=null){
						HSSFRow linkinrow  = sheet.getRow(rowIndex++);
						HSSFCell linkincell = linkinrow.getCell(21);
						if(currNode.hasProperty("inboundlinks")){

							linkincell.setCellValue(currNode.getProperty("inboundlinks").getLong()); 

						}
					}

				}



			}
			long endTime=System.currentTimeMillis();
			LOGGER.info(" New Excel Time: " + (endTime-startTime));
			String contentType = "application/vnd.ms-excel";
			response.setContentType(contentType);
			response.setHeader("Content-Disposition", "attachment;filename=Intel_Mobile_Content_Audit.xls");
			sheet.setDefaultColumnWidth(50);
			wb.write(out);
			out.flush();
			response.flushBuffer();


		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.error("Content Sync Exception:",e);
		}

	}
}
