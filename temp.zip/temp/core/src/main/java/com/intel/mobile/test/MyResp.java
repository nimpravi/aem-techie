package com.intel.mobile.test;

public class MyResp {
	public MyResp(String name,String addr){
		this.name = name;
		this.addr = addr;
		
	}
	private String name,addr;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}
	

}
