package com.intel.mobile.test;

import java.io.PrintWriter;

public interface IMyBean {
	public void displayString(PrintWriter writer);
}
