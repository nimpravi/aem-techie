/**
 * 
 */
package com.intel.mobile.services;

/**
 * @author skarm1
 *
 */

	public  interface SchedulerService{
		
}