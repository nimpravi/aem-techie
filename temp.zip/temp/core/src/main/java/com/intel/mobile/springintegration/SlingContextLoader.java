package com.intel.mobile.springintegration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.inject.Inject;
import javax.servlet.ServletContext;

import org.springframework.context.ApplicationContext;
import org.springframework.osgi.extensions.annotation.ServiceReference;
import org.springframework.osgi.web.context.support.OsgiBundleXmlWebApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ContextLoader;

/**
 * Create this as a bean so it's created when the bundle ApplicationContext is
 * initialized.
 * 
 */
@Component
public class SlingContextLoader extends ContextLoader {
  private ServletContext servletContext;

  private ApplicationContext applicationContext;

  public ApplicationContext getApplicationContext() {
    return applicationContext;
  }

  @Inject
  public void setApplicationContext(ApplicationContext applicationContext) {
    this.applicationContext = applicationContext;
  }

  public ServletContext getServletContext() {
    return servletContext;
  }

  /**
   * Retrieve a reference to the {@link javax.servlet.ServletContext
   * ServletContext} from the container for the
   * {@link org.springframework.osgi.web.context.support.OsgiBundleXmlWebApplicationContext
   * OsgiBundleXmlWebApplicationContext}
   * @param servletContext Instance of ServletContext
   */
  @ServiceReference
  public void setServletContext(ServletContext servletContext) {
    this.servletContext = servletContext;
  }

  /**
   * Return the type of {@link org.springframework.context.ApplicationContext
   * ApplicationContext} that we want to create. In our case, we want an
   * {@link org.springframework.context.ApplicationContext ApplicationContext}
   * that is OSGi aware and configured for Spring MVC.
   */
  @Override
  protected Class<?> determineContextClass(ServletContext currentServletContext) {
    return OsgiBundleXmlWebApplicationContext.class;
  }

  /**
   * Return the bundle {@link org.springframework.context.ApplicationContext
   * ApplicationContext} in order to properly access the bundles' classpath.
   */
  @Override
  protected ApplicationContext loadParentContext(ServletContext currentServletContext) {
    return applicationContext;
  }

  /**
   * Initialize the actual
   * {@link org.springframework.web.context.WebApplicationContext
   * WebApplicationContext} instance.
   */
  @PostConstruct
  public void init() {
    initWebApplicationContext(servletContext);
  }

  /**
   * Since we'll be running within an OSGi environment, the bundle may be
   * unregistered. This means we need to make sure we clean up the
   * {@link javax.servlet.ServletContext ServletContext} if this bundle is
   * unregistered.
   */
  @PreDestroy
  public void destroy() {
    closeWebApplicationContext(servletContext);
  }
}
