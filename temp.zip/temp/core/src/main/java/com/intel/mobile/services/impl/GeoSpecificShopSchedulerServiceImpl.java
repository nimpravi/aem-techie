/**
 * 
 */
package com.intel.mobile.services.impl;


import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferencePolicy;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.FrameworkUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.intel.mobile.services.GeoSpecificShopSchedulerService;
import com.intel.mobile.services.IntelConfigurationService;
import com.intel.mobile.services.NotificationService;
import com.intel.mobile.constants.IntelMobileConstants;
import com.intel.mobile.services.SchedulerService;
import com.intel.mobile.sync.ProductTypesSyschronizer;
import com.intel.mobile.sync.ProductsSynchronizer;
import com.intel.mobile.util.RepoUtil;
import com.intel.mobile.vo.ProductVO;
import com.intel.mobile.vo.SyncMessageVO;
import javax.jcr.query.InvalidQueryException;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.jcr.query.RowIterator;
/**
 * @author ggoswa
 *
 */

@Component (immediate=true, label="Intel GeoSpecific Shop API Scheduler", description = " Intel GeoSpecific  Shop API Scheduler", metatype=true, configurationFactory=true ) 
@Service 
@Properties({
	@Property(name = Constants.SERVICE_DESCRIPTION, value = "Intel Scheduler Service"),
	@Property(name = Constants.SERVICE_VENDOR, value = "Intel"),
	//@Property(name = "run.modes", value="author", cardinality = 2),
	@Property(name = "scheduler.concurrent",  boolValue=false),
	@Property(name = "scheduler.expression", value = "" , description = "Scheduler Cron Expressions. Follow the link http://www.docjar.com/docs/api/org/quartz/CronExpression.html for more details.")})



public class GeoSpecificShopSchedulerServiceImpl implements GeoSpecificShopSchedulerService,Runnable {



	private static final Logger LOG = LoggerFactory.getLogger(GeoSpecificShopSchedulerServiceImpl.class);

	@Reference
	private SlingRepository repository;
	@Reference
	private NotificationService notificationService;

	@Property(label = "Locale to be Synced", value = "", description = "The geo to run the sync job for")
	public static final String GEO_SYNC = "geoSync";
	private Session jcrSession;
	private String geo;
	protected void activate(ComponentContext context){
		try {
			LOG.info("activate method called");
			Dictionary props = context.getProperties();

			geo = (String) props.get(GEO_SYNC);

		} catch (Exception e){
			LOG.error(e.getMessage(), e);
		}
	}
	public void run() {

		String path=""; 
		String localeId=null;
		String localeLang="";
		String localekey="";
		Node localeNode=null;
		Map<String,List<ProductVO>> productsmap = new HashMap<String, List<ProductVO>>();
		List<ProductVO> products = new ArrayList<ProductVO>();
		LOG.info("Executing a cron job (job#1) for intel SHOP API to sync "+geo+" with CQ :"+Thread.currentThread().getId());
		SyncMessageVO messages = new SyncMessageVO();
		try {

			BundleContext bundleContext = FrameworkUtil.getBundle(SlingSettingsService.class).getBundleContext();  
			IntelConfigurationService intelConfigService = (IntelConfigurationService) bundleContext.getService(bundleContext.getServiceReference(IntelConfigurationService.class.getName()));
			if(intelConfigService.isSyncJobDisabled())
			{
				LOG.info("*** Intel Shop Sync Job is disabled ***");
				return;
			}
			LOG.info("Status :Inside run");
			SlingSettingsService slingSettingsService = (SlingSettingsService) bundleContext.getService(bundleContext.getServiceReference(SlingSettingsService.class.getName()));	
			NotificationService notificationService = (NotificationService) bundleContext.getService(bundleContext.getServiceReference(NotificationService.class.getName()));
			Set<String> runModes = slingSettingsService.getRunModes();
			LOG.info("Run Modes :"+runModes);
			if(runModes!=null && runModes.contains(IntelMobileConstants.RUN_MODE_AUTHOR)){
				LOG.info("repository :"+repository);
				jcrSession = RepoUtil.login(repository);
				javax.jcr.query.QueryManager queryManager = jcrSession.getWorkspace().getQueryManager();
				StringBuilder expression = new StringBuilder();
				expression.append("/jcr:root/content/intelmobile//");
				expression.append("*");
				expression.append("[jcr:content/@jcr:language =");
				String queryexp = expression.toString() + "'"+  geo + "'" + "]";
				LOG.info("QueryExpression:"+queryexp);
				Query query = queryManager.createQuery(queryexp,Query.XPATH);
				QueryResult results = null;
				results = query.execute();
				javax.jcr.NodeIterator nodeIter = results.getNodes();

				while ( nodeIter.hasNext() ) {

					localeNode = nodeIter.nextNode();

					if(localeNode.hasNode("jcr:content/locale")){
						Node localeInfoNode =  localeNode.getNode("jcr:content/locale");
						if(localeInfoNode.hasProperty("localeid") && localeInfoNode.hasProperty("language")){
							localeId = localeInfoNode.getProperty("localeid").getString();
							localeLang=localeInfoNode.getProperty("language").getString();
							localekey =localeLang + "("+localeId + ")";
						}
					} 
					LOG.info("Starting to sync the locale "+localeNode.getPath()+" , "+localeId);
					Map<String, String> productTypesMap = new ProductTypesSyschronizer().syncProductTypes(jcrSession, messages);
					if(!messages.getFailureList().isEmpty()){
						LOG.info("Product Types Synchronizer Service Failure. ");
						//notificationService.notifyErrorMessages(messages.getFailureList(), "Product Types Synchronizer Service");
					}
					if(!messages.getSuccessList().isEmpty()){
						LOG.info("Product Types Synchronizer Service Success. ");
						//notificationService.notifySuccessMessages(messages.getSuccessList(), "Product Types Synchronizer Service");

					}
					messages = null;
					messages = new SyncMessageVO();						
					ProductsSynchronizer productssynchroniser = new ProductsSynchronizer();
					if(localeId!=null && !(StringUtils.equals(localeId,"0"))){
						products=productssynchroniser.syncLocaleSpecificProducts(jcrSession, productTypesMap,localeId,localeNode.getPath(),"all", messages);
					}
					//products=new ProductsSynchronizer().syncProducts(jcrSession,productTypesMap, messages);
					if(!messages.getFailureList().isEmpty()){
						notificationService.notifyErrorMessages(messages.getFailureList(), "Products Synchronizer Service");
					}
					if(!messages.getSuccessList().isEmpty()){
						notificationService.notifySuccessMessages(messages.getSuccessList(), "Products Synchronizer Service");										
					}
					if(!products.isEmpty()){

						productsmap.put(localekey, products);	
					}
					LOG.info("productsmap :"+productsmap);
					if(!productsmap.isEmpty()){
						notificationService.productbatchMail(productsmap);
					}
					LOG.info("Products Created:"+products);
				}

				jcrSession.logout();
			}else{
				LOG.debug("The service will only run in author mode.Skip the execution.");
			}

		} catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException :", e);
		}
		catch (InvalidQueryException e)
		{
			LOG.error("InvalidQueryException :", e);
		}
		catch (RepositoryException e) {
			LOG.error("RepositoryException :", e);
		} 
		catch (Exception e)
		{
			LOG.error("Exception :", e);
		} 
	}

}
