package com.intel.mobile.vo;

public class ProductVO {
	String productcatergory;
	String producttitle;
	public String getProducttitle() {
		return producttitle;
	}
	public void setProducttitle(String producttitle) {
		this.producttitle = producttitle;
	}

	String productname;
	String producturl;
	public String getProductcatergory() {
		return productcatergory;
	}
	public void setProductcatergory(String productcatergory) {
		this.productcatergory = productcatergory;
	}
	public ProductVO(String productcatergory, String producttitle,
			String productname, String producturl) {
		super();
		this.productcatergory = productcatergory;
		this.producttitle = producttitle;
		this.productname = productname;
		this.producturl = producturl;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProducturl() {
		return producturl;
	}
	public void setProducturl(String producturl) {
		this.producturl = producturl;
	}
	public ProductVO(String productcatergory, String productname,
			String producturl) {
		super();
		this.productcatergory = productcatergory;
		this.productname = productname;
		this.producturl = producturl;
	}
	public ProductVO() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append("Name : ").append(getProductname()).append(" , ");
		strBuffer.append("Category : ").append(getProductcatergory()).append(" , ");
		strBuffer.append("URL : ").append(getProducturl()).append(" , ");
		strBuffer.append("Title: ").append(getProducttitle()).append(" , ");
		;
		
		return strBuffer.toString();
	}
	
	
}
