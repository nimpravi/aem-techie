package com.intel.mobile.servlets;

import java.io.IOException;

import java.net.URLDecoder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jcr.Session;
import javax.mail.internet.InternetAddress;

import org.apache.commons.mail.HtmlEmail;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.intel.mobile.util.IntelUtil;
import com.intel.mobile.util.RepoUtil;

import javax.jcr.Node;

/**
 * @author skarm1
 * 
 */

@Component(immediate = true, metatype = false, label = "Processor Spec Email Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/SpecsEmail") })
public class SpecsEmailServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SpecsEmailServlet.class);
	@Reference
	private SlingRepository repository;

	/*
	 * @Reference private JcrResourceResolverFactory jcrResolverFactory;
	 */

	/*
	 * @Reference private MessageGatewayService messageGatewayService;
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.sling.api.servlets.AllMethodsServlet#doPost(org.apache
	 * .sling.api.HttpServletRequest, org.apache.api.SlingHttpServletResponse)
	 */
	public void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws IOException {
		LOGGER.info("Entered the doPost method.");
		String emailAddress = request.getParameter("emailAddress");
		String processor = request.getParameter("processor");
		String ram = request.getParameter("ram");
		String hardDrive = request.getParameter("hardDrive");
		String screenSize = request.getParameter("screenSize");
		String portability = request.getParameter("portability");
		String specsLink = request.getParameter("specsLink");
		String specsLocale = request.getParameter("specsLocale");
		String strServerName = request.getServerName();
		int iServerPort = request.getServerPort();
		try {

			if (null == specsLocale || specsLocale.trim().length() == 0) {
				specsLocale = "en_US";
			}
			if (null == processor || processor.trim().length() == 0) {
				processor = "test";
			}

			
		//	processor = URLDecoder.decode(processor,"UTF-8");
			LOGGER.info("emailAddress : " + emailAddress);
			LOGGER.info("processor : " + processor);
			LOGGER.info("ram : " + ram);
			LOGGER.info("hardDrive : " + hardDrive);
			LOGGER.info("screenSize : " + screenSize);
			LOGGER.info("portability : " + portability);
			LOGGER.info("specsLink : " + specsLink);

			LOGGER.info("specsLocale : " + specsLocale);
			LOGGER.info("Domain Name : " + request.getServerName());
			
			
			String[] strArrProc = processor.split(" ");
			String strProcessor = "";
			for(String strProc: strArrProc){
				if(strProc.contains("Intel")){
					strProcessor = strProcessor +strProc+"<sup>&reg;</sup> ";
				}else if(strProc.contains("Core")){
					strProcessor = strProcessor+strProc+"<sup>&trade;</sup> ";
				}else{
					strProcessor = strProcessor+strProc;
				}
			}
			
			LOGGER.info("processor with trademark : " + strProcessor);
			
			String template = "/etc/designs/intelmobile/emailTemplates/Template_en_US.vm";
			Session jcrSession = RepoUtil.login(repository);

			HashMap<String, String> hmProperties = new HashMap<String, String>();
			hmProperties.put("processor", strProcessor);
			hmProperties.put("ram", ram);
			hmProperties.put("hardDrive", hardDrive);
			hmProperties.put("screenSize", screenSize);
			hmProperties.put("yourPreferences", portability);
			hmProperties.put("specsLink", specsLink);
			hmProperties.put("serverName", strServerName);

			HtmlEmail email = new HtmlEmail();
			List<InternetAddress> lstTomailID = new ArrayList<InternetAddress>();
			InternetAddress objToID = new InternetAddress();
			objToID.setAddress(emailAddress);
			lstTomailID.add(objToID);
			email.setTo(lstTomailID);

			//email.setSubject("Here are your PC spec recommendations");

			Node templatenode = jcrSession.getNode(template).getNode("jcr:content");
			
			if (null == templatenode) {
				LOGGER.error("Template does not exist :" + template);
			} else {

				String templateText = templatenode.getProperty("jcr:data")
						.getString();
				// LOGGER.info("###### Original ########BODY :"+templateText);

				for (String key : hmProperties.keySet()) {
					templateText = templateText.replace("$" + key,
							hmProperties.get(key));
				}
				// LOGGER.info("$$$$ Replaced $$$$$$BODY :"+templateText);
				jcrSession.logout();
				IntelUtil.sendMail(emailAddress, "noreply@intel.com", "Here are your PC spec recommendations",
						templateText, null, null, "", "");
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Exception : ", e);
		}

	}

	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws IOException {

		doPost(request, response);
	}

}
