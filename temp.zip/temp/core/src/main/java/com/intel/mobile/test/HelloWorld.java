/**
 * 
 */
package com.intel.mobile.test;

import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;

public class HelloWorld implements IHelloWorld {

	@Autowired
	IMyBean bean;

	public void getList(int dep,PrintWriter out) {
		bean.displayString(out);
	}
}
