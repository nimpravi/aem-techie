package com.intel.mobile.servlets;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Session;
import javax.jcr.Workspace;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.JcrTagManagerFactory;
import com.intel.mobile.util.RepoUtil;

/**
 * 
 * @author phegd1
 * 
 */

@Component(immediate = true, metatype = false, label = "Image Service Validator Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/ImageValidator") })
public class ImageServiceResponseValidatorServlet extends
		SlingAllMethodsServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ImageServiceResponseValidatorServlet.class);
	private static final String NODE_PROPERTY_FOR_DOWNLOAD = "picture"; // property
																		// of
																		// node
																		// to be
																		// downloaded
																		// as
																		// excel
	@Reference
	private SlingRepository repository;

	@Reference
	private JcrTagManagerFactory jcrTagManagerFactory;

	private Session jcrSession;

	@Override
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		OutputStream out = response.getOutputStream();
		String paramLocale = request.getParameter("locale");
		String exportUrl = "/content/intelmobile/";
		if (null == paramLocale) {
			exportUrl = exportUrl + "%";
		} else {
			paramLocale = paramLocale.toLowerCase();
			String[] localeArray = paramLocale.split("_");
			exportUrl = exportUrl + localeArray[1] + "/" + localeArray[0]
					+ "/%";
		}

		// String downloadOption=request.getParameter("downloadOption");
		// TreeMap<String, ProductsBean[]> productsMap=new TreeMap<String,
		// ProductsBean[]>();

		String queryString = "select * from nt:base where jcr:path like '"
				+ exportUrl
				+ "' and cq:lastReplicationAction= 'Activate' and cq:template='/apps/intelmobile/templates/productdetails'";
		try {
			jcrSession = RepoUtil.login(repository);
			Workspace workspace = jcrSession.getWorkspace();
			QueryManager queryManager = workspace.getQueryManager();
			Query query = queryManager.createQuery(queryString, Query.SQL);
			// execute query
			QueryResult result = query.execute();
			NodeIterator it = result.getNodes();
			int count = 0;
			Node tempNode = null;
			String category = "";
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet = wb.createSheet("Image_Service_Status");
			sheet.setAutobreaks(true);
			int rownum = 0;
			int cellnum = 0;
			HSSFRow row = sheet.createRow(rownum++);
			HSSFCell cell = row.createCell(cellnum++);
			HSSFCellStyle style = wb.createCellStyle();
			style.setAlignment(style.ALIGN_LEFT);
			style.setFillForegroundColor(HSSFColor.LIME.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			HSSFFont font = wb.createFont();
			font.setColor(HSSFColor.RED.index);
			style.setFont(font);
			cell.setCellStyle(style);
			cell.setCellValue("Page Name");
			cell = row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("Page URL");
			cell = row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("Image URL");
			cell = row.createCell(cellnum++);
			cell.setCellStyle(style);
			cell.setCellValue("Image URL Connection Status");
			long startTime = System.currentTimeMillis();

			String domainName = request.getServerName();
			URL url;
			// String
			// protocol=request.getProtocol().split("/").length>1?request.getProtocol().split("/")[0]:request.getProtocol();
			while (it.hasNext()) {
				cellnum = 0;
				tempNode = it.nextNode();
				if (tempNode.hasNode("details")) {
					Node detailsNode = tempNode.getNode("details");
					if (detailsNode.hasProperty(NODE_PROPERTY_FOR_DOWNLOAD)) {

						String imageUrl = detailsNode.getProperty(
								NODE_PROPERTY_FOR_DOWNLOAD).getString();
						url = new URL(imageUrl);
						HttpsURLConnection connection = (HttpsURLConnection) url
								.openConnection();
						connection.setHostnameVerifier(new HostnameVerifier() {
							public boolean verify(String hostname,
									SSLSession session) {
								return true;
							}
						});
						connection.setRequestMethod("GET");
						connection.setConnectTimeout(500);
						connection.connect();
						try {
							if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
								row = sheet.createRow(rownum++);
								cell = row.createCell(cellnum++);
								/*
								 * cell.setCellValue(category);
								 * cell=row.createCell(cellnum++);
								 */
								cell.setCellValue(tempNode.getParent()
										.getName());
								cell = row.createCell(cellnum++);
								cell.setCellValue("http://" + domainName
										+ tempNode.getParent().getPath()
										+ "/html");
								cell = row.createCell(cellnum++);
								cell.setCellValue(detailsNode.getProperty(
										NODE_PROPERTY_FOR_DOWNLOAD).getString());
								cell = row.createCell(cellnum++);
								cell.setCellValue(connection.getResponseCode());
							}
						} catch (Exception e) {
							row = sheet.createRow(rownum++);
							cell = row.createCell(cellnum++);
							/*
							 * cell.setCellValue(category);
							 * cell=row.createCell(cellnum++);
							 */
							cell.setCellValue(tempNode.getParent().getName());
							cell = row.createCell(cellnum++);
							cell.setCellValue("http://" + domainName
									+ tempNode.getParent().getPath() + "/html");
							cell = row.createCell(cellnum++);
							cell.setCellValue(detailsNode.getProperty(
									NODE_PROPERTY_FOR_DOWNLOAD).getString());
							cell = row.createCell(cellnum++);
							cell.setCellValue(HttpURLConnection.HTTP_GATEWAY_TIMEOUT);
						}
					}
				}
			}

			long endTime = System.currentTimeMillis();
			/*
			 * List<ProductsMappingBean> productsBeanList=new
			 * ArrayList<ProductsMappingBean>(); long
			 * startTime=System.currentTimeMillis(); for(int
			 * i=0;it.hasNext();i++) { tempNode=it.nextNode();
			 * category=tempNode.getParent().getParent().getName();
			 * if(category.equals("products") ||
			 * tempNode.getParent().getName().equals("products")) continue;
			 * productsBeanList.add(new
			 * ProductsMappingBean(tempNode.getParent().
			 * getName(),tempNode.getParent
			 * ().getPath(),tempNode.hasProperty("relativeurl"
			 * )?tempNode.getProperty
			 * ("relativeurl").getString():"",category.toLowerCase())); }
			 * Collections.sort(productsBeanList); for(ProductsMappingBean
			 * productsBean:productsBeanList) { cellnum=0; row =
			 * sheet.createRow(rownum++); cell=row.createCell(cellnum++);
			 * cell.setCellValue(productsBean.getPageName());
			 * cell=row.createCell(cellnum++);
			 * cell.setCellValue(productsBean.getMobilePagePath());
			 * cell=row.createCell(cellnum++);
			 * cell.setCellValue(productsBean.getDesktopRelativeUrl()); } long
			 * endTime=System.currentTimeMillis();
			 */
			LOGGER.info("Excel Time: " + (endTime - startTime));
			String contentType = "application/vnd.ms-excel";
			response.setContentType(contentType);
			response.setHeader("Content-Disposition",
					"attachment;filename=Image_Service_Status.xls");
			sheet.setDefaultColumnWidth(50);
			wb.write(out);
			out.flush();
			response.flushBuffer();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.info("An exception has occured: ", e);
		}

	}

}
