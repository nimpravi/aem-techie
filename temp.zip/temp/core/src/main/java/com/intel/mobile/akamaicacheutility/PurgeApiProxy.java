package com.intel.mobile.akamaicacheutility;

public class PurgeApiProxy implements com.intel.mobile.akamaicacheutility.PurgeApi {
  private String _endpoint = null;
  private com.intel.mobile.akamaicacheutility.PurgeApi purgeApi = null;
  
  public PurgeApiProxy() {
    _initPurgeApiProxy();
  }
  
  public PurgeApiProxy(String endpoint) {
    _endpoint = endpoint;
    _initPurgeApiProxy();
  }
  
  private void _initPurgeApiProxy() {
    try {
      purgeApi = (new com.intel.mobile.akamaicacheutility.JavaClassesLocator()).getPurgeApi();
      if (purgeApi != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)purgeApi)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)purgeApi)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (purgeApi != null)
      ((javax.xml.rpc.Stub)purgeApi)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.intel.mobile.akamaicacheutility.PurgeApi getPurgeApi() {
    if (purgeApi == null)
      _initPurgeApiProxy();
    return purgeApi;
  }
  
  public com.intel.mobile.akamaicacheutility.PurgeResult purgeRequest(java.lang.String name, java.lang.String pwd, java.lang.String network, java.lang.String[] opt, java.lang.String[] uri) throws java.rmi.RemoteException{
    if (purgeApi == null)
      _initPurgeApiProxy();
    return purgeApi.purgeRequest(name, pwd, network, opt, uri);
  }
  
  
}