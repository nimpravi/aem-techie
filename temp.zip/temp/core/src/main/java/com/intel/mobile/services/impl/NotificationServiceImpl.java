package com.intel.mobile.services.impl;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.InternetAddress;

import org.apache.commons.mail.HtmlEmail;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferencePolicy;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.intel.mobile.services.NotificationService;
import com.intel.mobile.vo.MonitorDetailsVO;
import com.intel.mobile.vo.ProductVO;

/**
 * 
 * @author ujverm
 *
 */

@Component (immediate=true, label="Notification Service", description = "Notification Service", metatype=true )
@Service 
@Properties({
	@Property(name = Constants.SERVICE_DESCRIPTION, value = "Notification Service"),
	@Property(name = Constants.SERVICE_VENDOR, value = "Intel")})

public class NotificationServiceImpl implements NotificationService {

	@Reference (policy=ReferencePolicy.STATIC)	
	private MessageGatewayService messageGatewayService;

	private static final Logger LOGGER = 
			LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Property(label = "Recipient Email Addresses", value = "", description = "Email addresses to send messages.")
	public static final String NOTIFICATION_EMAIL_ADDR = "notificationEmailAddr";

	@Property(label = "Sender's Email Address", value = "", description = "Email address to use for Sender")
	public static final String FROM_EMAIL_ADDR = "fromEmailAddr";

	@Property(label = "Send Success Notifications",  boolValue = true , description = "Do you want to send success notifications ?")
	public static final String SEND_SUCCESS_NOTIFICATION = "sendSuccessNotifications";

	@Property(label = "Send Failure Notifications",  boolValue = true , description = "Do you want to send failure notifications ?")
	public static final String SEND_FAILURE_NOTIFICATION = "sendFailureNotifications";

	@Property(label = " Product Batch Mail Host Name", value="http://m-author.intel.com" , description = "Host name to be used to send mail")
	public static final String HOST_NAME = "hostName";

	private String notificationEmailAddr;
	private String fromEmailAddr;
	private boolean sendSuccessNotifications;
	private boolean sendFailureNotifications;
	private String hostName;
	protected void activate(ComponentContext context){

		try {
			LOGGER.debug("activate method called");
			Dictionary props = context.getProperties();

			notificationEmailAddr = (String) props.get(NOTIFICATION_EMAIL_ADDR);
			fromEmailAddr = (String) props.get(FROM_EMAIL_ADDR);
			sendSuccessNotifications = (Boolean) props.get(SEND_SUCCESS_NOTIFICATION);
			sendFailureNotifications = (Boolean) props.get(SEND_FAILURE_NOTIFICATION);
			hostName=(String)props.get(HOST_NAME);

		} catch (Exception e){
			LOGGER.error(e.getMessage(), e);
		}
	}

	public void notifyErrorMessages(List<String> messages, String service) {
		if(sendFailureNotifications) {
			LOGGER.error("Notify error message called with parameter - " + messages);
			HtmlEmail email = new HtmlEmail();
			List<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();	 	
			StringBuilder emailMessage = new StringBuilder();

			emailMessage.append("<p>Following errors occurred while running ");
			emailMessage.append(service);
			emailMessage.append(":<br /><ol>");
			for(String msg:messages) {
				emailMessage.append("<li>");
				emailMessage.append(msg);
				emailMessage.append("</li>");
			}
			emailMessage.append("</ol></p>");
			emailMessage.append("<p>Please contact your administrator or check logs for more information.");

			try {
				String emails[] = notificationEmailAddr.split(",");

				for(int i=0;i<emails.length;i++) {
					if(isEmailCorrect(emails[i])) {
						InternetAddress address = new InternetAddress(emails[i].trim());
						emailAddresses.add(address);	 				
					} 
				}

				email.setTo(emailAddresses);
				email.setFrom(fromEmailAddr);
				email.setSubject("Notification: Intel " + service + " errors");
				email.setHtmlMsg(emailMessage.toString());
				MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
				if(messageGateway != null){
					messageGateway.send(email);
				}
				else {
					LOGGER.error("Message gateway is null will not be able to send mail");
				}

			} catch (Exception e ) {
				LOGGER.error( "Fatal error while sending failure notification ", e );
			}					
		}
	}

	public void notifySuccessMessages(List<String> messages, String service) {
		if(sendSuccessNotifications) {		
			HtmlEmail email = new HtmlEmail();
			List<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();	 	
			StringBuilder emailMessage = new StringBuilder();

			emailMessage.append("<p>");	 	
			emailMessage.append(service);
			emailMessage.append(" completed successfully. Following are the notes:");
			emailMessage.append(":<br /><ol>");
			for(String msg:messages) {
				emailMessage.append("<li>");
				emailMessage.append(msg);
				emailMessage.append("</li>");
			}
			emailMessage.append("</ol></p>");

			try {
				String emails[] = notificationEmailAddr.split(",");

				for(int i=0;i<emails.length;i++) {
					if(isEmailCorrect(emails[i])) {
						InternetAddress address = new InternetAddress(emails[i].trim());
						emailAddresses.add(address);	 				
					} 
				}

				email.setTo(emailAddresses);
				email.setFrom(fromEmailAddr);
				email.setSubject("Notification: Intel " + service + " success");
				email.setHtmlMsg(emailMessage.toString());
				MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
				if(messageGateway != null) {
					messageGateway.send(email);
				}
			} catch (Exception e ) {           
				LOGGER.error( "Fatal error while sending success notification ", e );
			}
		}
	}	

	public boolean isEmailCorrect(String email) {

		final String EMAIL_PATTERN = 
				"^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);

		Matcher matcher = pattern.matcher(email);
		return matcher.matches();		
	}

	public void  productbatchMail( Map<String, List<ProductVO>> productlist){
		HtmlEmail email = new HtmlEmail();
		List<ProductVO> products= new ArrayList<ProductVO>();
		List<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();
		StringBuilder emailMessage = new StringBuilder();
		emailMessage.append("<p>");


		Iterator<Map.Entry<String, List<ProductVO>>> iter = productlist.entrySet().iterator();
		while (iter.hasNext()) {
			int count = 1;
			Map.Entry<String, List<ProductVO>> mEntry = iter.next();
			products= mEntry.getValue();
			emailMessage.append("<br />");
			emailMessage.append("Following are the newly created products for :"+ mEntry.getKey() );
			Iterator<ProductVO> iterator = products.iterator();
			emailMessage.append(":<br />");
			emailMessage.append("<table width=\"50%\" border=1>");
			emailMessage.append("<th>");
			emailMessage.append("Sl no");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Product Title");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Product Category");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Product Name");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Product URL");
			emailMessage.append("</th>");
			while(iterator.hasNext()){
				//Map.Entry<String,String> entry = entries.next();
				ProductVO product = new ProductVO();
				product=iterator.next();	
				emailMessage.append("<tr>");
				emailMessage.append("<td>");
				emailMessage.append(count);
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(product.getProducttitle());
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(product.getProductcatergory());
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(product.getProductname());
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append("<a href=\"");
				emailMessage.append(hostName + "/");
				emailMessage.append(product.getProducturl());
				emailMessage.append(".html");
				emailMessage.append("\">");
				emailMessage.append(product.getProducturl()); 
				emailMessage.append("</a>");
				emailMessage.append("</td>");
				emailMessage.append("</tr>");
				count++;
			}
			emailMessage.append("</table>");
		}
		emailMessage.append("</p>");
		LOGGER.info("emailMessage :"+emailMessage.toString());
		try {
			String emails[] = notificationEmailAddr.split(",");

			for(int i=0;i<emails.length;i++) {
				if(isEmailCorrect(emails[i])) {
					InternetAddress address = new InternetAddress(emails[i].trim());
					emailAddresses.add(address);	 				
				} 
			}

			email.setTo(emailAddresses);
			email.setFrom(fromEmailAddr);
			email.setSubject("Notification: Intel new product created");
			email.setHtmlMsg(emailMessage.toString());
			LOGGER.info("messageGatewayService :"+messageGatewayService);
			MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
			LOGGER.info("messageGateway :"+messageGateway);
			if(messageGateway != null) {
				messageGateway.send(email);
				LOGGER.info("Email sent for the products created after SHOP Sync.");
			}
		} catch (Exception e ) {           
			LOGGER.error( "Fatal error while sending success notification ", e );
		}
	}

	public void productErrorMail(String messages) {
		if(sendSuccessNotifications) {		
			HtmlEmail email = new HtmlEmail();
			List<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();	 	
			StringBuilder emailMessage = new StringBuilder();
			emailMessage.append("Following  error occured while running the workflow:"  );
			emailMessage.append("<li>");
			emailMessage.append(messages);
			emailMessage.append("</li>");
			LOGGER.info("Error Message:"+emailMessage.toString());

			try {
				String emails[] = notificationEmailAddr.split(",");

				for(int i=0;i<emails.length;i++) {
					if(isEmailCorrect(emails[i])) {
						InternetAddress address = new InternetAddress(emails[i].trim());
						emailAddresses.add(address);	 				
					} 
				}

				email.setTo(emailAddresses);
				email.setFrom(fromEmailAddr);
				email.setSubject("Notification: Intel Product Category Error");
				email.setHtmlMsg(emailMessage.toString());
				MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
				if(messageGateway != null) {
					messageGateway.send(email);
				}
			} catch (Exception e ) {           
				LOGGER.error( "Fatal error while sending product category error notification ", e );
			}
		}
	}	
	public void QueryErrorMail(String messages) {
		if(sendSuccessNotifications) {		
			HtmlEmail email = new HtmlEmail();
			List<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();	 	
			StringBuilder emailMessage = new StringBuilder();
			emailMessage.append("Intel Shop API Query invalid:"  );
			emailMessage.append("<li>");
			emailMessage.append(messages);
			emailMessage.append("</li>");
			emailMessage.append("<br/>");
			emailMessage.append("Please enter a valid query");
			LOGGER.info("Error Message:"+emailMessage.toString());

			try {
				String emails[] = notificationEmailAddr.split(",");

				for(int i=0;i<emails.length;i++) {
					if(isEmailCorrect(emails[i])) {
						InternetAddress address = new InternetAddress(emails[i].trim());
						emailAddresses.add(address);	 				
					} 
				}

				email.setTo(emailAddresses);
				email.setFrom(fromEmailAddr);
				email.setSubject("Notification: Intel Product Category Error");
				email.setHtmlMsg(emailMessage.toString());
				MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
				if(messageGateway != null) {
					messageGateway.send(email);
				}
			} catch (Exception e ) {           
				LOGGER.error( "Fatal error while sending product category error notification ", e );
			}
		}
	}

	public void productmonitorMail(Map<String, List<MonitorDetailsVO>> monitorDetails) {
		// TODO Auto-generated method stub
		HtmlEmail email = new HtmlEmail();
		List<MonitorDetailsVO> products= new ArrayList<MonitorDetailsVO>();
		List<InternetAddress> emailAddresses = new ArrayList<InternetAddress>();
		StringBuilder emailMessage = new StringBuilder();
		emailMessage.append("<p>");


		Iterator<Map.Entry<String, List<MonitorDetailsVO>>> iter = monitorDetails.entrySet().iterator();
		while (iter.hasNext()) {
			int count = 1;
			Map.Entry<String, List<MonitorDetailsVO>> mEntry = iter.next();
			products= mEntry.getValue();
			emailMessage.append("<br />");
			emailMessage.append("Product Monitoring result for :"+ mEntry.getKey() );
			Iterator<MonitorDetailsVO> iterator = products.iterator();
			emailMessage.append(":<br />");
			emailMessage.append("<table width=\"50%\" border=1>");
			emailMessage.append("<th>");
			emailMessage.append("Sl no");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Product Category");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Initial Count");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Final Count");
			emailMessage.append("</th>");
			emailMessage.append("<th>");
			emailMessage.append("Total Change");
			emailMessage.append("</th>");
			while(iterator.hasNext()){
				//Map.Entry<String,String> entry = entries.next();
				MonitorDetailsVO monitordetails = new MonitorDetailsVO();
				monitordetails=iterator.next();	
				emailMessage.append("<tr>");
				emailMessage.append("<td>");
				emailMessage.append(count);
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(monitordetails.getCategory());
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(monitordetails.getInitial_count());
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(monitordetails.getFinal_count());
				emailMessage.append("</td>");
				emailMessage.append("<td>");
				emailMessage.append(monitordetails.getPercentage_change());
				emailMessage.append("</td>");
				emailMessage.append("</tr>");
				count++;
			}
			emailMessage.append("</table>");
		}
		emailMessage.append("</p>");
		LOGGER.info("emailMessage :"+emailMessage.toString());
		try {
			String emails[] = notificationEmailAddr.split(",");

			for(int i=0;i<emails.length;i++) {
				if(isEmailCorrect(emails[i])) {
					InternetAddress address = new InternetAddress(emails[i].trim());
					emailAddresses.add(address);	 				
				} 
			}

			email.setTo(emailAddresses);
			email.setFrom(fromEmailAddr);
			email.setSubject("Notification: Product Monitoring Results");
			email.setHtmlMsg(emailMessage.toString());
			LOGGER.info("messageGatewayService :"+messageGatewayService);
			MessageGateway<HtmlEmail> messageGateway = messageGatewayService.getGateway(HtmlEmail.class);
			LOGGER.info("messageGateway :"+messageGateway);
			if(messageGateway != null) {
				messageGateway.send(email);
				LOGGER.info("Email sent for the products monitored.");
			}
		} catch (Exception e ) {           
			LOGGER.error( "Fatal error while sending shop monitor mail ", e );
		}


	}	



}







