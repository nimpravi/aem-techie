package com.intel.mobile.test;

import java.io.PrintWriter;


public interface IHelloWorld {

	public void getList(int dep,PrintWriter out);
}
