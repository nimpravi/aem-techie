package com.intel.mobile.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;

import javax.jcr.Session;
import javax.jcr.Workspace;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.commons.lang.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FastSeedListUtil extends SimpleTagSupport{

	private static final Logger LOGGER = LoggerFactory.getLogger(FastSeedListUtil.class);
	private String rootPath;
	private Writer out;
	private int minutes;
	private String seedChoice;
	private Session jcrSession;
	private List<String> exceptionPaths;
	private String domainName;
	
	
	
	public String getRootPath() {
		return rootPath;
	}
	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}
	public Writer getOut() {
		return out;
	}
	public void setOut(Writer out) {
		this.out = out;
	}
	public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	public String getSeedChoice() {
		return seedChoice;
	}
	public void setSeedChoice(String seedChoice) {
		this.seedChoice = seedChoice;
	}
	public Session getJcrSession() {
		return jcrSession;
	}
	public void setJcrSession(Session jcrSession) {
		this.jcrSession = jcrSession;
	}
	public List<String> getExceptionPaths() {
		return exceptionPaths;
	}
	public void setExceptionPaths(List<String> exceptionPaths) {
		this.exceptionPaths = exceptionPaths;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	@Override
	public void doTag() throws JspException, IOException {
		
		draw(getRootPath(),getOut(),getMinutes(),getSeedChoice());
	}
	public void draw(String rootPath,Writer out,int minutes,String seedChoice){
		
			
			LOGGER.info("*************Inside Draw Of FastSeedUtil***************");
			Workspace workspace = jcrSession.getWorkspace();
			String queryString;
			Calendar cal = Calendar.getInstance(java.util.TimeZone.getDefault());
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
			long currentTimeInMillis = cal.getTimeInMillis();
			long currentTimeInMillisMinusPeriod = minutes*60*1000;
			long requiredTimeInMillis = currentTimeInMillis - currentTimeInMillisMinusPeriod;
			Date requiredDateTime = new Date( requiredTimeInMillis );
			
			String requiredDateTimeFormatted = dateFormat.format(requiredDateTime);
			String currentTime=dateFormat.format(currentTimeInMillis);
			
			cal.add(Calendar.MINUTE, -(minutes));
			//Date date=cal.getTime();
			//Timestamp timeStamp=new Timestamp(date.getTime());
			//String queryString="select * from nt:base where ( jcr:lastModified >= TIMESTAMP '"+requiredDateTimeFormatted.trim()+"' ) and (jcr:lastModified >= TIMESTAMP '"+currentTime+"') and jcr:path like '"+rootPath+"/%' and cq:lastReplicationAction= 'ACTIVATE'";
			
			/*StringBuffer sb = new StringBuffer();
			sb.append("/jcr:root");
			sb.append(rootPath);
			sb.append("//element(*,nt:base)");
			sb.append("[");
			sb.append("jcr:content/@jcr:lastModified >= xs:dateTime('");
			sb.append(requiredDateTimeFormatted);
			sb.append("')");
			sb.append(" and ");
			sb.append("jcr:content/@cq:lastReplicationAction= 'ACTIVATE'");
			sb.append("]");
			String xpathStatement = sb.toString();*/
			
			
			if(seedChoice.equals("activatedPages")){
				queryString="select * from nt:base where jcr:path like '"
						+ rootPath + "/%' and cq:lastReplicationAction= 'Activate'";
			}
			
			else{
				
				queryString="select * from nt:base where jcr:path like '"
					+ rootPath + "/%' and cq:lastReplicationAction= 'Deactivate'";
			}
			
			
			/*
			StringBuffer sb = new StringBuffer();
			
			sb.append("select * from nt:base where ");
			sb.append("( jcr:lastModified >= TIMESTAMP '");
			sb.append(dateFormat.format(cal.getTime()));
			sb.append("' )");
			sb.append(" and ");
			sb.append("jcr:path like '"+rootPath);
			sb.append("/%' and cq:lastReplicationAction= 'ACTIVATE'");*/
			
			/*String queryString=sb.toString();*//*"select * from nt:base where jcr:path like '"
					+ rootPath + "%' and cq:lastReplicationAction= 'ACTIVATE' and jcr:lastModified >='"+date+"'";*/
			
			
			
			/*StringBuffer sb1 = new StringBuffer();
			sb1.append("select * from nt:resource where ");
			sb1.append("( jcr:lastModified >= TIMESTAMP '");
			sb1.append("2013-06-04T15:34:15.917+02:00");
			sb1.append("' )");
			sb1.append(" and ");
			sb1.append("( jcr:lastModified <= TIMESTAMP '");
			sb1.append("2008-06-04T15:34:15.917+02:00");
			sb1.append("' )");
			String sqlStatement = sb1.toString();*/
			
			try {
				QueryManager queryManager = workspace.getQueryManager();
				Query query =queryManager.createQuery(queryString, Query.SQL);
				QueryResult result = query.execute();
				NodeIterator it = result.getNodes();
				PrintWriter writer=new PrintWriter(out);
				while (it.hasNext()){
					Node node=it.nextNode();
					if(exceptionPaths.size()>0 && exceptionPaths.contains(node.getParent().getPath()))
						continue;
					writer.printf("<a href=\"%s.html\" style=\"color:white;margin-left:20px;\">%s</a></br>",node.getParent().getPath(),node.hasProperty("jcr:title")?node.getProperty("jcr:title").getString():node.getParent().getName());
					
				}
				
			} catch (Exception e) {
				LOGGER.error("An Exception has occured", e);
			}
		
		
	}
	
}
