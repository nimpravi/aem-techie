package com.intel.mobile.workflow;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import com.day.cq.dam.core.AbstractAssetProcess;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.FrameworkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import com.day.cq.dam.api.DamManager;
import com.day.cq.dam.core.AbstractAssetProcess;
import com.day.cq.replication.Agent;
import com.day.cq.replication.AgentFilter;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationOptions;
import com.day.cq.replication.Replicator;
import com.day.cq.wcm.api.Page;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.JavaProcessExt;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.intel.mobile.services.IntelConfigurationService;
import com.intel.mobile.services.NotificationService;
import com.intel.mobile.services.impl.NotificationServiceImpl;
import com.intel.mobile.sync.ProductTypesSyschronizer;
import com.intel.mobile.sync.ProductsSynchronizer;
import com.intel.mobile.sync.QueryProductsSynchronizer;
import com.intel.mobile.vo.ProductVO;
import com.intel.mobile.vo.SyncMessageVO;

import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.jcr.resource.JcrResourceResolverFactory;
import org.apache.sling.settings.SlingSettingsService;

/**
 * @author ggoswa
 *
 */

@Component(immediate = true, metatype = false, label = "Specific Arguement Sync Workflow") 
@Service
@Properties({
	@Property(name = Constants.SERVICE_DESCRIPTION, value = "Specific Arguement Sync Workflow"),
	@Property(name = Constants.SERVICE_VENDOR, value = "Intel")})


public class SpecificArguementSyncWorkflow implements WorkflowProcess{
	@Reference
	private SlingRepository repository;
	@Reference
	private JcrResourceResolverFactory resourceResolverFactory;

	@Reference
	private NotificationService notificationService;

	private Session jcrSession;
	private static final Logger LOG = LoggerFactory.getLogger(SpecificArguementSyncWorkflow.class);

	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) {
		//Session session1 = null;
		String syncType=args.get("syncoptions" ,new String("not set"));
		String query=args.get("query", new String("not set"));
		String[] multiValue = args.get("categoryoptions", new String[]{"not set"});
		try {
			jcrSession = repository.loginAdministrative(null);
		} catch (RepositoryException rpe) {
			// TODO Auto-generated catch block
			LOG.error("Exception:",rpe);
		}
		final ResourceResolver resourceResolver = resourceResolverFactory.getResourceResolver(jcrSession);
		Map<String,List<ProductVO>> productsmap = new HashMap<String,List<ProductVO>>();
		List<ProductVO> products = new ArrayList<ProductVO>();
		String path=""; 
		String localeId="";
		String localeLang="";
		String localekey="";
		WorkflowData workflowData = item.getWorkflowData();
		try{
			if (workflowData.getPayloadType() == "JCR_PATH") { 
				path = workflowData.getPayload().toString();  
			}
			LOG.info("WorkflowPath:"+path);
			//final Page page = resourceResolver.getResource(path).adaptTo(Page.class);
			Resource resource=resourceResolver.getResource(path);
			//LOG.info("Activated the Digital asset :"+asset.getPath());
			Node localeNode=resource.adaptTo(Node.class);
			if(localeNode.hasNode("jcr:content/locale")){
				Node localeInfoNode =  localeNode.getNode("jcr:content/locale");
				if(localeInfoNode.hasProperty("localeid") && localeInfoNode.hasProperty("language")){
					localeId = localeInfoNode.getProperty("localeid").getString();
					localeLang=localeInfoNode.getProperty("language").getString();
					localekey =localeLang + "("+localeId + ")";
				}
			}

			LOG.info("Starting to sync the locale "+localeNode.getPath()+" , "+localeId);
			String categories = StringUtils.join(multiValue,",");
			LOG.info("Categories:"+ categories);
			SyncMessageVO messages = new SyncMessageVO();
			Map<String, String> productTypesMap = new ProductTypesSyschronizer().syncProductTypes(jcrSession, messages);
			if(syncType.equals("category")){
				ProductsSynchronizer productssynchroniser = new ProductsSynchronizer();
				if(categories!=null && StringUtils.isNotEmpty(categories) &&localeId!=null && !(StringUtils.equals(localeId,"0")))
					products=productssynchroniser.syncLocaleSpecificProducts(jcrSession, productTypesMap,localeId,localeNode.getPath(),categories, messages);
			}
			if(syncType.equals("query")){
				QueryProductsSynchronizer queryproductssynchroniser = new QueryProductsSynchronizer();
				if(query!=null && StringUtils.isNotEmpty(query) && localeId!=null && !(StringUtils.equals(localeId,"0")))
					products=queryproductssynchroniser.syncLocaleSpecificProducts(jcrSession, productTypesMap,localeId,localeNode.getPath(),query, messages);
			}
			if(syncType.equals("all")){
				ProductsSynchronizer productssynchroniser = new ProductsSynchronizer();
				if(localeId!=null && !(StringUtils.equals(localeId,"0"))){
					products=productssynchroniser.syncLocaleSpecificProducts(jcrSession, productTypesMap,localeId,localeNode.getPath(),"all", messages);
				}
			}
			if(!products.isEmpty()){
				productsmap.put(localekey, products);
			}
			LOG.info("productsmap :"+productsmap);
			if(!productsmap.isEmpty()){
				notificationService.productbatchMail(productsmap);
			}
			LOG.info("Products Created:"+products);
			// jcrSession.logout();
		}catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException :"+e.getMessage());

		} catch (RepositoryException e) {
			LOG.error("RepositoryException :"+e.getMessage());

		} catch (Exception e) {
			LOG.error("Exception :"+e.getMessage());


		}

	}  

	public void execute(WorkItem arg0, WorkflowSession arg1) throws Exception {
		// TODO Auto-generated method stub

	}


}







