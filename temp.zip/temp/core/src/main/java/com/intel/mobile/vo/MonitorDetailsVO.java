package com.intel.mobile.vo;

public class MonitorDetailsVO {

String category;
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public long getInitial_count() {
	return initial_count;
}
public void setInitial_count(Long productsCount) {
	this.initial_count = productsCount;
}
public long getFinal_count() {
	return final_count;
}
public MonitorDetailsVO(String category, long initial_count, long final_count,
		long percentage_change) {
	super();
	this.category = category;
	this.initial_count = initial_count;
	this.final_count = final_count;
	this.percentage_change = percentage_change;
}
public MonitorDetailsVO() {
	// TODO Auto-generated constructor stub
}
public void setFinal_count(long final_count) {
	this.final_count = final_count;
}
public long getPercentage_change() {
	return percentage_change;
}
public void setPercentage_change(long percentage_change) {
	this.percentage_change = percentage_change;
}
long initial_count;
long final_count;
long percentage_change;

@Override
public String toString() {
	
	StringBuffer strBuffer = new StringBuffer();
	
	strBuffer.append("Category : ").append(getCategory()).append(" , ");
	strBuffer.append("Initial count : ").append(getInitial_count()).append(" , ");
	strBuffer.append("Final count: ").append(getFinal_count()).append(" , ");
	strBuffer.append("Percentage change:").append( getPercentage_change()).append(",")
	;
	
	return strBuffer.toString();
}




}
