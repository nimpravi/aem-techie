package com.intel.mobile.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.jcr.resource.JcrResourceResolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Binary;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFactory;
import javax.jcr.Workspace;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import com.intel.mobile.util.IntelUtil;
import com.intel.mobile.util.Status;

/**
 * 
 * @author
 *
 */


@Component(immediate = true, metatype = false, label = "Import RelativeUrl Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/ImportSeoTitleDesc")})

public class UploadSeoTitleDescServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	@Reference
	private JcrResourceResolverFactory resourceResolverFactory;
	@Reference
	private SlingRepository repository;  

	// location to store file uploaded
	private static final String UPLOAD_DIRECTORY = "/content/usergenerated/intelmobile/us/en/fileuploadseo/uploadnode/1364365644147_1";

	// upload settings
	private static final int MEMORY_THRESHOLD   = 1024 * 1024 * 3;  // 3MB
	private static final int MAX_FILE_SIZE      = 1024 * 1024 * 40; // 40MB
	private static final int MAX_REQUEST_SIZE   = 1024 * 1024 * 50; // 50MB
	private Session jcrSession;
	private static final String NODE_PROPERTY_DESCRIPTION   = "jcr:description"; //property to be modified with values in excel
	private static final String NODE_PROPERTY_TITLE   = "pageTitle";
	private static final Logger LOGGER = LoggerFactory.getLogger(UploadSeoTitleDescServlet.class);

	public void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws IOException {

		String output="Nodes are updated successfully with the values of Excel sheet";
		
		try {
			jcrSession = repository.loginAdministrative(null);
		} catch (RepositoryException rpe) {
			// TODO Auto-generated catch block
			LOGGER.error("Exception:",rpe);
		}
		if (!ServletFileUpload.isMultipartContent(request)) {
			// if not, we stop here
			PrintWriter writer = response.getWriter();
			writer.println("Error: Form must has enctype=multipart/form-data.");
			writer.flush();
			return;
		}

		// configures upload settings
		DiskFileItemFactory factory = new DiskFileItemFactory();
		// sets memory threshold - beyond which files are stored in disk 
		factory.setSizeThreshold(MEMORY_THRESHOLD);
		// sets temporary location to store files
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

		ServletFileUpload upload = new ServletFileUpload(factory);

		// sets maximum size of upload file
		upload.setSizeMax(MAX_FILE_SIZE);

		// sets maximum size of request (include file + form data)
		upload.setSizeMax(MAX_REQUEST_SIZE);

		// constructs the directory path to store upload file
		// this path is relative to application's directory
		//String uploadPath = UPLOAD_DIRECTORY;

		// creates the directory if it does not exist
		final boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		PrintWriter out = null;
		try {
			// parses the request's content to extract file data
			//@SuppressWarnings("unchecked")
			// List<FileItem> formItems = upload.parseRequest(request);
			String uploadPath= request.getParameter("path");
			String type=request.getParameter("type");
			LOGGER.info("Request Parameter:"+ uploadPath + type);
			out = response.getWriter();
			//LOGGER.info("Form Items:"+formItems );
			Node node=null;
			Node fileNode=null;
			Node resNode=null;
			if (isMultipart) {
				final Map<String, RequestParameter[]> params = request.getRequestParameterMap();
				for (final Map.Entry<String, RequestParameter[]> pairs : params.entrySet()) {
					final String k = pairs.getKey();
					final RequestParameter[] pArr = pairs.getValue();
					final RequestParameter param = pArr[0];
					final InputStream is = param.getInputStream();
					String filename = param.getFileName();
					if (param.isFormField()) {
						// out.println("Form field " + k + " with value " + Streams.asString(stream) + " detected.");
					} else {
						Node objTagNode = null;
						try{
						short pagePathColumn=0;  
					    short titleColumn=1;
					    short descriptionColumn = 2 ;
					    int i=0;   
					    
					    Map<String, String> mNodeTitle = new HashMap<String, String>(); 
					    String   value1="", value2="", value3=""; 
					    Workspace workspace=jcrSession.getWorkspace();
					    
					    HSSFWorkbook wb = new HSSFWorkbook(is); 
					       // System.out.println("Total Number of sheets : "+wb.getNumberOfSheets());
					        
					        for(int j = 0; j < wb.getNumberOfSheets(); j++){    
					            //System.out.println("Sheet Number : "+k);
					         HSSFSheet sheet = wb.getSheetAt(j);    
					         int rows  = sheet.getPhysicalNumberOfRows();    
					         //System.out.println("Sheet Name : "+wb.getSheetName(k)+" ::: Number of Rows : "+rows);
					         for(int r =     1; r < rows; r++){    
					            HSSFRow row   = sheet.getRow(r);    
					         //int cells = row.getPhysicalNumberOfCells();    
					            HSSFCell cell1  = row.getCell(pagePathColumn);  
					            //System.out.println("Row 1 :"+value1);
					            if (cell1.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
					                 value1 = ""+cell1.getNumericCellValue(); 
					            }else if(cell1.getCellType() == HSSFCell.CELL_TYPE_STRING){
					                 value1 = cell1.getStringCellValue(); 
					            }
					             
					            HSSFCell cell2  = row.getCell(titleColumn);   
					            //System.out.println(cell2.);
					            if (cell2.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
					             value2 = ""+cell2.getNumericCellValue(); 
					           }else if(cell2.getCellType() == HSSFCell.CELL_TYPE_STRING){
					             value2 = cell2.getStringCellValue(); 
					           }
					            HSSFCell cell3  = row.getCell(descriptionColumn);   
					            //System.out.println(cell2.);
					            if (cell3.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
					             value3 = ""+cell3.getNumericCellValue(); 
					           }else if(cell3.getCellType() == HSSFCell.CELL_TYPE_STRING){
					             value3 = cell3.getStringCellValue(); 
					           }
                                if((value2 != "" && value2 != null) || (value3 != "" && value3 != null))
					            mNodeTitle.put(value1+"/jcr:content", value2+"|"+value3);
					          }       
					          i++;   
					        } 
					        //System.out.println("Total Number of Nodes : "+mNodeTitle.size());

					       // log.info("N");
					        
					       Set<Map.Entry<String, String>> entrySetNodes = mNodeTitle.entrySet();
					       Iterator<Map.Entry<String, String>> itrNodes = entrySetNodes.iterator();
					       
					        while(itrNodes.hasNext()){
					        
					            Map.Entry<String, String> entry = itrNodes.next();
					            
					            LOGGER.info("Path : "+entry.getKey() +" Value : "+entry.getValue());
					            String titleval = "";
					            String descval = "";
					            if(entry.getValue().length()>1 && !entry.getValue().startsWith("|")){
					             titleval = entry.getValue().substring(0,entry.getValue().indexOf("|"));
					            }else {
					            	titleval = "";
					            }
					            if(entry.getValue().length()>1){
					             descval = entry.getValue().substring(entry.getValue().indexOf("|")+1,entry.getValue().length());
					            }else {
					            	descval = "";
					            }
					            if(jcrSession.nodeExists(entry.getKey())){
					            	//LOGGER.info("resource---nodetype-- "+jcrSession.getNode(entry.getKey()).getPrimaryNodeType().getName());
					            	if(jcrSession.getNode(entry.getKey()).getPrimaryNodeType().getName().equalsIgnoreCase("cq:PageContent") || jcrSession.getNode(entry.getKey()).getPrimaryNodeType().getName().equalsIgnoreCase("nt:unstructured")){
					                 objTagNode = jcrSession.getNode(entry.getKey()); 
					                 //LOGGER.info("---------Inside If----------with title--"+titleval+"description value--"+descval);
					                 if(objTagNode.hasProperty(NODE_PROPERTY_TITLE)){
					                	 objTagNode.setProperty(NODE_PROPERTY_TITLE,titleval);
					                 }else{
					                	 objTagNode.setProperty(NODE_PROPERTY_TITLE,titleval);
					                	 //LOGGER.info("The Property "+NODE_PROPERTY_TITLE+" does not exist for node "+objTagNode);
					                 }
					                 if(objTagNode.hasProperty(NODE_PROPERTY_DESCRIPTION)){
					                	 objTagNode.setProperty(NODE_PROPERTY_DESCRIPTION,descval);
					                 }else{
					                	 objTagNode.setProperty(NODE_PROPERTY_DESCRIPTION,descval);
					                	 //LOGGER.info("The Property "+NODE_PROPERTY_DESCRIPTION+" does not exist for node "+objTagNode);
					                 }
					                 }
					            }else{
					            	LOGGER.info("Node does not exist :" + entry.getKey());
					            
					            }
					    // System.out.println(entry.getKey()+" :: "+entry.getValue());
					         objTagNode = null;
					        }
					        jcrSession.save();
					        if(is!=null)
					        	is.close();
					   
					}catch(Exception e){  
						LOGGER.error("Exception "+e+" for Node "+objTagNode);
						output="Nodes are not updated successfully with the values of Excel sheet :-see logs for more details";
					}
					  						
					}
				}
			}


		} catch (Exception ex) {

			LOGGER.info("There was an error: ",ex);
		}
		// redirects client to message page
		out.println(output);
	}
	protected void doGet(SlingHttpServletRequest request,SlingHttpServletResponse response) throws IOException {


	}

}
