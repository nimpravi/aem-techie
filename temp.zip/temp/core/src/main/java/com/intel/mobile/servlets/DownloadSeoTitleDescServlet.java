package com.intel.mobile.servlets;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Workspace;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.JcrTagManagerFactory;
import com.intel.mobile.util.RepoUtil;

/**
 * 
 * @author 
 *
 */


@Component(immediate = true, metatype = false, label = "Export RelativeUrl Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/ExportSeoTitleDesc") })


public class DownloadSeoTitleDescServlet extends SlingAllMethodsServlet{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadSeoTitleDescServlet.class);
	private static final String NODE_PROPERTY_FOR_DESCRIPTION   = "jcr:description"; 
	private static final String NODE_PROPERTY_FOR_TITLE   = "pageTitle";//property of node to be downloaded as excel
	@Reference
	private SlingRepository repository;

	@Reference
	private JcrTagManagerFactory jcrTagManagerFactory;


	private Session jcrSession;
	
	
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}
	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		OutputStream out = response.getOutputStream();
		String paramLocale = request.getParameter("locale").toLowerCase();
		if(null ==paramLocale)
			paramLocale="en_us";
		String[] localeArray=paramLocale.split("_");
		String downloadOption=request.getParameter("downloadOption");
		//TreeMap<String, ProductsBean[]> productsMap=new TreeMap<String, ProductsBean[]>();
		String exportUrl="/content/intelmobile/"+localeArray[1]+"/"+localeArray[0]+"/%";
		String queryString="select * from nt:base where jcr:path like '"+exportUrl+"' and cq:lastReplicationAction= 'Activate'";
		try {
			jcrSession = RepoUtil.login(repository);
			Workspace workspace=jcrSession.getWorkspace();
			QueryManager queryManager = workspace.getQueryManager();
			Query query = queryManager.createQuery(queryString, Query.SQL);
            // execute query
            QueryResult result = query.execute();
            NodeIterator it = result.getNodes();
            int count=0;
            Node tempNode=null;
            String category="";
            HSSFWorkbook wb = new HSSFWorkbook();
            HSSFSheet sheet = wb.createSheet("Seo_Data_Sheet");
            sheet.setAutobreaks(true);
            int rownum=0;
            int cellnum=0;
            HSSFRow row  = sheet.createRow(rownum++);
            HSSFCell cell = row.createCell(cellnum++);
            HSSFCellStyle style=wb.createCellStyle();
            style.setAlignment(style.ALIGN_LEFT);
            style.setFillForegroundColor(HSSFColor.LIME.index);
            style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
            HSSFFont font = wb.createFont();
            font.setColor(HSSFColor.RED.index);
            style.setFont(font);
            cell.setCellStyle(style);
            cell.setCellValue("Page Path");
            cell=row.createCell(cellnum++);
            cell.setCellStyle(style);
            cell.setCellValue("Title");
            cell=row.createCell(cellnum++);
            cell.setCellStyle(style);
            cell.setCellValue("Description");
            
            long startTime=System.currentTimeMillis();
            
            if(downloadOption.equals("actualData"))
            {
            	while(it.hasNext())
	            {
	              cellnum=0;
	              tempNode=it.nextNode();
	              //if(tempNode.hasProperty(NODE_PROPERTY_FOR_TITLE ) || tempNode.hasProperty(NODE_PROPERTY_FOR_DESCRIPTION))
	              if(tempNode.hasProperties())
	              {
	            	  row = sheet.createRow(rownum++);
		              cell=row.createCell(cellnum++);
		              cell.setCellValue(tempNode.getParent().getPath());
		              cell=row.createCell(cellnum++);
		              if(tempNode.hasProperty(NODE_PROPERTY_FOR_TITLE)){
		              cell.setCellValue(tempNode.getProperty(NODE_PROPERTY_FOR_TITLE).getString());
		              }else cell.setCellValue("");
		              cell=row.createCell(cellnum++);
		              if(tempNode.hasProperty(NODE_PROPERTY_FOR_DESCRIPTION)){
		              cell.setCellValue(tempNode.getProperty(NODE_PROPERTY_FOR_DESCRIPTION).getString());
		              }else cell.setCellValue("");
		           }
	             
	            }
            }
            long endTime=System.currentTimeMillis();
           
            LOGGER.info("Excel Time: " + (endTime-startTime));
			String contentType = "application/vnd.ms-excel";
	        response.setContentType(contentType);
            response.setHeader("Content-Disposition", "attachment;filename=Intel_Mobile_Seodata.xls");
           	sheet.setDefaultColumnWidth(50);
			wb.write(out);
			out.flush();
			response.flushBuffer();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			e.toString();
		}
		
	}
}
