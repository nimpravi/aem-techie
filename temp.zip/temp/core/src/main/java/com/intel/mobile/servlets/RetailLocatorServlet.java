package com.intel.mobile.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import com.intel.mobile.services.IntelConfigurationService;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.io.IOUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;


@Component(immediate = true, metatype = false, label = "Shop Retail Locator Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/retailerservice/getretaillocator") })



public class RetailLocatorServlet extends SlingAllMethodsServlet{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(RetailLocatorServlet.class);
	

	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
	
		
	}
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		LOGGER.info("Inside Get method");
		HttpURLConnection connection = null;
        BufferedReader rd  = null;
        StringBuilder sb = null;
        String line = null;
        URL serverAddress = null;
        ArrayList<String> resultList = new ArrayList<String>();
		List  jsonList = new LinkedList();
		Enumeration paramNames = request.getParameterNames();
		LOGGER.info("parameters"+paramNames);
		String confirmationto = null;
		String redirect = null;
		String shopQuery = null;
		String intelServiceURL = null;
		String queryParameters = "";
		
		BundleContext bundleContext = FrameworkUtil.getBundle(IntelConfigurationService.class).getBundleContext();  
		IntelConfigurationService intelConfigService = (IntelConfigurationService) bundleContext.getService(bundleContext.getServiceReference(IntelConfigurationService.class.getName()));
		
		intelServiceURL = intelConfigService.getIntelShopAPIUrl();
		LOGGER.info("Intel service url :"+intelServiceURL);
		while (paramNames.hasMoreElements()) {
			JSONObject json = new JSONObject();
			String paramName = (String) paramNames.nextElement();
			String[] paramValues = request.getParameterValues(paramName);
			String pValue="";
			for( int i = 0; i <= paramValues.length - 1; i++) {     
				pValue +=(i==0?"":",")+paramValues[i] ;
			}
		
		    if(pValue != null){
				//urlPost=urlPost+paramName+ "-"+pValue.toString()+"&";
					 queryParameters=queryParameters+paramName+ "="+pValue.toString()+"&";
				 }
		      }
		LOGGER.info("queryParameters "+queryParameters);
		//shopQuery = urlPost+URLEncoder.encode(queryParameters, "UTF-8"); // Or "UTF-8".
		shopQuery = intelServiceURL+"/retailerservice/getretailerstores?" + queryParameters;
		try{

            serverAddress = new URL(shopQuery);
            //set up communications
            connection = null;
          
            //Set up the initial connection
            connection = (HttpURLConnection)serverAddress.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoOutput(true);
            connection.setReadTimeout(10000);
                 
            connection.connect();
                      
            //read the result from the server
            LOGGER.info("searchQuery:"+shopQuery);
            LOGGER.info("connection.getResponseCode() :"+connection.getResponseCode());
            if (connection.getResponseCode() == 200){
            	rd  = new BufferedReader(new InputStreamReader(connection.getInputStream(),"UTF-8"));
            } else {
            	rd  = new BufferedReader(new InputStreamReader(connection.getErrorStream(),"UTF-8"));
            }
          
            //rd  = new BufferedReader(new InputStreamReader(connection.getInputStream(),"UTF-8"));
            sb = new StringBuilder();
            
            while ((line = rd.readLine()) != null)
            {
                sb.append(line + '\n');
            }
            String searchResult =  sb.toString();
            LOGGER.info("searchResult :"+searchResult);
            
                   JSONObject object = new JSONObject(searchResult);
				    
			       // object.put("name",);
					//object.put("value",resultList);
					
					
					response.setContentType("application/json;charset=utf-8");
					//response.setContentType("application/json");
					response.getWriter().write(object.toString());      
        
		}
		catch (JSONException e) {
			LOGGER.error("JSONException :"+e.getMessage());
			LOGGER.debug("JSONException :",e);
		}
		catch (MalformedURLException e) {
        	LOGGER.error("MalformedURLException :"+e.getMessage());
        	LOGGER.debug("MalformedURLException :",e);
        } catch (ProtocolException e) {
        	LOGGER.error("ProtocolException :"+e.getMessage());
        	LOGGER.debug("ProtocolException :",e);
        } catch (IOException e) {
        	LOGGER.error("IOException :"+e.getMessage());
        	LOGGER.debug("IOException :",e);
        }
        finally
        {
            //close the connection, set all objects to null
            connection.disconnect();
            rd = null;
            connection = null;
        }

	     
	}
	  
	  
	}




