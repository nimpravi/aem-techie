package com.intel.mobile.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.Calendar;


import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;


@Component(immediate = true, metatype = false, label = "Download Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/Download") })



public class DownloadServlet extends SlingAllMethodsServlet{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadServlet.class);
	 private Calendar calendar = Calendar.getInstance();


	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		doPost(request,response);
		
	}
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		try {
			String sttime = request.getParameter("starttime");
			sttime = sttime.replace(":","");
			//LOGGER.info("starttime ----"+sttime);
			String entime = request.getParameter("endtime");
			entime = entime.replace(":","");
			String stdate = request.getParameter("stdate");
			stdate = stdate.replace("-","");
			stdate = stdate+"T"+sttime+"Z";
			String endate = request.getParameter("endate");
			endate = endate.replace("-","");
			endate = endate+"T"+entime+"Z";
			//LOGGER.info("startdate"+stdate);
			String summary = request.getParameter("summary");
			String location = request.getParameter("location");
			String timezone = request.getParameter("timezone");
			//String fileArray = request.getParameter("params"); 
			    String contentType = "text/x-vCalendar";
		        response.setContentType(contentType);
                response.setHeader("Content-Disposition", "attachment;filename=calendarev.ics");
				PrintWriter out = response.getWriter();
				out.write("BEGIN:VCALENDAR\r\n");
	            out.write("VERSION:1.0\r\n");
	            out.write("PRODID:-//Iris Advies//XPlanner//EN\r\n");
	            out.write("BEGIN:VEVENT\r\n");
                out.write("SUMMARY:" + summary + "\r\n");
                out.write("LOCATION:" + location + "\r\n");
                out.write("DTSTART:" +stdate + "\r\n");
                out.write("DTEND:" + endate + "\r\n");
                out.write("END:VEVENT\r\n");
                out.write("END:VCALENDAR\r\n");
                out.flush();
		}
		catch (Exception e) {
			LOGGER.error("exception in  Download servlet",e);
		}
	}

	

}
