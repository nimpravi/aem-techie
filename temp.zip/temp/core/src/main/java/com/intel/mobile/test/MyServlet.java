package com.intel.mobile.test;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;

public class MyServlet extends SlingAllMethodsServlet {
	
	@Autowired
	IMyBean bean;

	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {

		response.setContentType("application/json");
		ServletOutputStream out = response.getOutputStream();
		MyResp ob = new MyResp("Praveen", "Sapient");
		new ObjectMapper().writeValue(out, ob);

		bean.displayString(response.getWriter());

	}

	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		doGet(request, response);
	}
}
