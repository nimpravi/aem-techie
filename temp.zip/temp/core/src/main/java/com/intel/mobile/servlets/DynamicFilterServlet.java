package com.intel.mobile.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.settings.SlingSettingsService;
import org.codehaus.jackson.map.ObjectMapper;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.springframework.context.ApplicationContext;
import org.springframework.osgi.web.context.support.OsgiBundleXmlWebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.intel.mobile.test.IHelloWorld;
import com.intel.mobile.test.MyResp;
import com.intel.mobile.vo.ProductVO;


@Component(immediate=true,metatype=false,label="")
@Service(value=javax.servlet.Servlet.class)
@Properties({@Property(name="sling.servlet.paths",value="/bin/DynamicFilter")})
public class DynamicFilterServlet extends SlingAllMethodsServlet{

	@Override
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		// TODO Auto-generated method stub
		super.doPost(request, response);
	}
	@Override
	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		
		//Map<String,Map<String,String>> selectedFiltersMap= (Map<String,Map<String,String>>)request.getAttribute("selectedFilters");
		//String category=request.getParameter("category");
		
		//response.sendRedirect("http://localhost:4506/content/intelmobile/us/en/products/ultrabooks/acer-s7-storm.touch.html");
		/*ServletContext sc=getServletContext();
		ApplicationContext ac=WebApplicationContextUtils.getWebApplicationContext(sc);*/
		/*ProductVO productVO=(ProductVO)ac.getBean("productVO");
		productVO.setProductname(request.getParameter("productName"));
		PrintWriter out=response.getWriter();
		out.println("Product Info: "+productVO.getProductname());*/
		BundleContext bundle=FrameworkUtil.getBundle(SlingSettingsService.class).getBundleContext();
		IHelloWorld mc1 = (IHelloWorld)bundle.getService(bundle.getServiceReference(IHelloWorld.class.getName()));
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		MyResp ob = new MyResp("Praveen", "Sapient");
		new ObjectMapper().writeValue(out, ob);
		mc1.getList(1,out);
	}
}
