package com.intel.mobile.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;


@Component(immediate = true, metatype = false, label = "Form Post Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/intel/Formpost") })



public class FormPostServlet extends SlingAllMethodsServlet{
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(FormPostServlet.class);
	

	protected void doGet(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		LOGGER.info("ResourceTypePostServlet::doGet()");
		doPost(request,response);
		
	}
	protected void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws ServletException,
			IOException {
		LOGGER.info("ResourceTypePostServlet::doPost()");
		List  jsonList = new LinkedList();
		Enumeration paramNames = request.getParameterNames();
		LOGGER.info("parameters"+paramNames);
		String confirmationto = null;
		String redirect = null;
		String urlPost = null;
		String succMsg = null;
		String errMsg = null;
		String queryParameters = "";
		while (paramNames.hasMoreElements()) {
			JSONObject json = new JSONObject();
			String paramName = (String) paramNames.nextElement();
			String[] paramValues = request.getParameterValues(paramName);
			String pValue="";
			for( int i = 0; i <= paramValues.length - 1; i++) {     
				pValue +=(i==0?"":",")+paramValues[i] ;
			}
			if(paramName.equals("sucmsg")){
				succMsg=paramValues[0];
			    continue;
			}
			if(paramName.equals("errmsg")){
				errMsg=paramValues[0];
			    continue;
			}
			if(paramName.equals("url")){
				urlPost=paramValues[0];
				urlPost= urlPost + "?";
				continue;
			}
			//System.out.println(paramName+"|"+pValue);
			LOGGER.info("urlPost"+urlPost);
			LOGGER.info("paramName"+paramName);
			LOGGER.info("paramValues"+paramValues);
			try {
				 if(pValue != null){
				//urlPost=urlPost+paramName+ "-"+pValue.toString()+"&";
					 queryParameters=queryParameters+paramName+ "-"+pValue.toString()+"&";
				 }
				 json.put("Name",paramName);
				 json.put("value",pValue.toString());
				 jsonList.add(json);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		LOGGER.info("queryParameters "+queryParameters);
		urlPost = urlPost+URLEncoder.encode(queryParameters, "UTF-8"); // Or "UTF-8".
		LOGGER.info("JSON "+jsonList.toString());
		LOGGER.info("Posturl"+urlPost);
		String line = null;
		StringBuilder sb = null;
		String  responseText ="";
		 BufferedReader rd  = null; 
	      HttpClient httpClient = new HttpClient( );
	      GetMethod getMethod = null;
	      try{
	      getMethod = new GetMethod(urlPost);
	      httpClient.executeMethod(getMethod);
	      //display the response to the POST Method
	      LOGGER.info("status code "+getMethod.getStatusCode());
	      if (getMethod.getStatusCode() == HttpStatus.SC_OK) {
	    	 // JSONObject json = new JSONObject();
	    	 // rd  = new BufferedReader(new InputStreamReader(getMethod.getResponseBodyAsStream(),"UTF-8"));
	    	  responseText = getMethod.getResponseBodyAsString();
	    	  LOGGER.info("response body "+responseText);
	    	  response.setContentType("text/html");
	    	  java.io.PrintWriter out = response.getWriter();
	    	  if(succMsg != null){
	    		  out.println(succMsg);
	    	  }else{
	    	  out.println("Form is submitted successfully");
	    	  }
	      }
	     else {
		      response.setContentType("text/html");
		      java.io.PrintWriter out = response.getWriter( );
		      if( errMsg != null){
	    	  
		    	  out.println(errMsg);
		      }else
		      {
		    	  out.println("Form Submission failed.");
		      }

	      }
	      }
	      catch(Exception e)
		     {
	    	  response.setContentType("text/html");
	    	  java.io.PrintWriter out = response.getWriter( );
	    	  if( errMsg != null){
		    	  
		    	  out.println(errMsg);
		      }else
		      {
		    	  out.println("Form Submission failed.");
		      }
		     LOGGER.error("Unable to execute :"+e.getMessage());
		     }finally{
		        //release the connection used by the method
		      getMethod.releaseConnection( );
		     }
	       
	}



}
