package com.intel.mobile.workflow;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.DamManager;
import com.day.cq.replication.Agent;
import com.day.cq.replication.AgentFilter;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationOptions;
import com.day.cq.replication.Replicator;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.JavaProcessExt;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

/**
 * @author ggoswa
 *
 */

@Component(immediate = true, metatype = false, label = "Preview Activation Servlet")
@Service
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/PreviewActivation") })
public class PreviewActivation implements WorkflowProcess {

	@Reference
	private com.day.cq.replication.Replicator replicator;

	private static final Logger LOG = LoggerFactory 
			.getLogger(PreviewActivation.class);

	private Session session;
	ReplicationOptions opts;
	public void execute(WorkItem item, WorkflowSession workFlowSession, MetaDataMap args) {
		// Session session1 = null;
		String path = "";
		opts = new ReplicationOptions();
		opts.setFilter(new AgentFilter(){
			public boolean isIncluded(final Agent agent) {
				return "preview".equals(agent.getId());
				//return agent.getId();
			}
		});

		WorkflowData workflowData = item.getWorkflowData();

		session = workFlowSession.getSession();

		try {
			if (workflowData.getPayloadType().equals("JCR_PATH")) { 
				path = workflowData.getPayload().toString();  
			
			Node startNode = session.getNode(path);
			LOG.info("PayLoad:"+path);
			replicator.replicate(session, ReplicationActionType.ACTIVATE, path,opts);
			}
			else{
				workFlowSession.terminateWorkflow(item.getWorkflow());
	            return;
			}
		
			//workFlowSession.terminateWorkflow(item.getWorkflow());   
		
		} catch (Exception e) {
			LOG.error("Exception:", e); 
		}
		// LOG.info("HelloWorld");
	}

	public void execute(WorkItem arg0, WorkflowSession arg1) throws Exception {
		// TODO Auto-generated method stub

	}

} 





