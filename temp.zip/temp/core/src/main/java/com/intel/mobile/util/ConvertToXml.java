package com.intel.mobile.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;

import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.intel.mobile.constants.IntelMobileConstants;

/**
 * 
 * @author dmoha1
 *
 */
public class ConvertToXml {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConvertToXml.class);
	public static String getcovertToXML(Map<String,Map<String, String>> map,Map<String,Map<String, String>> fmap,Map<String, String> smap) {
		LOGGER.info("Inside convertxml class");
		        
		        StringBuilder sb = new StringBuilder("<");
	               sb.append("products");
		           sb.append(">");
		        for (Map.Entry<String,Map<String, String>> e : map.entrySet()) {
		        	sb.append("<");
		        	sb.append("product");
			        sb.append(">");
		        	sb.append("<");
  		            sb.append("name");
  		            sb.append(">");
  		            
		        	sb.append(e.getKey());
		        	
		        	sb.append("</");
	  		        sb.append("name");
	  		        sb.append(">");
		        	for(Map.Entry<String, String> entries : e.getValue().entrySet()){
		        		if(entries.getKey().contains("filterprocessor0")){
		        			sb.append("<");
		 		            sb.append("filterprocessorlist");
		 		            sb.append(">");
		        		}
		        		if(entries.getKey().contains("filterprocessor")||entries.getKey().contains("filterprolast")){
		        			
		        			sb.append("<");
		  		            sb.append("filterprocessor");
		  		            sb.append(">");

		  		            sb.append(entries.getValue());
		  		            sb.append("</");
		  		            sb.append("filterprocessor");
		  		            sb.append(">");
		        		}else{
		            sb.append("<");
		            sb.append(entries.getKey());
		            sb.append(">");

		            sb.append(entries.getValue());
		            sb.append("</");
		            sb.append(entries.getKey());
		            sb.append(">");
		        		}
		            if(entries.getKey().equals("filterprolast")){
	        			 sb.append("</");
	 		            sb.append("filterprocessorlist");
	 		            sb.append(">");
	        		}
		        }
		        	sb.append("</");
		        	sb.append("product");
			        sb.append(">");
		        	
		        }
		        
		        sb.append("</");
		        sb.append("products");
		        sb.append(">");
		        //sb.append("<");
		        
		        
		        
	        	  /*sb.append("sortoptions");
		           sb.append(">");
		           
		           for(Map.Entry<String, String> entries : smap.entrySet()){
			           String key1=entries.getKey(); 
		        	   sb.append("<");
			            sb.append(key1.contains(":")?key1.substring(key1.indexOf(":")+1):key1);
			            sb.append(">");

			            sb.append(entries.getValue());
			            sb.append("</");
			            sb.append(key1.contains(":")?key1.substring(key1.indexOf(":")+1):key1);
			            sb.append(">");
			            
			        }
		           
		           
		           sb.append("</");
			        sb.append("sortoptions");
			        sb.append(">");
			        
			        
			        
			        
			        sb.append("<");
		        	  sb.append("filteroptions");
			           sb.append(">");
			           
			           for (Map.Entry<String,Map<String, String>> e : fmap.entrySet()) {
			        	   String key=e.getKey();  
			        	   sb.append("<");
				        	  sb.append(key.contains("`")?key.substring(key.indexOf("`")+1):key);
					          sb.append(">");
				        	for(Map.Entry<String, String> entries : e.getValue().entrySet()){
				        		String key2=entries.getKey();
				        	sb.append("<");
				            sb.append(key2.contains("-")?key2.replaceAll("-","_"):key);
				            sb.append(">");

				            sb.append(entries.getValue());
				            sb.append("</");
				            sb.append(key2.contains("-")?key2.replaceAll("-","_"):key);
				            sb.append(">");
				            
				        }
				        	sb.append("</");
				            sb.append(key.contains("`")?key.substring(key.indexOf("`")+1):key);
				            sb.append(">");
				        }
			           
			           
			           sb.append("</");
				        sb.append("filteroptions");
				        sb.append(">");*/
		       
		        LOGGER.info("xml string :"+sb.toString());
		        return sb.toString();
		 
		
		
	}
	
	
}
