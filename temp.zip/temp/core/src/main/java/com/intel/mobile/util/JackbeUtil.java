package com.intel.mobile.util;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;
import javax.servlet.jsp.PageContext;

import org.apache.commons.io.IOUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.intel.mobile.constants.IntelMobileConstants;
import com.intel.mobile.services.IntelConfigurationService;

public class JackbeUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(JackbeUtil.class);
	public static void processProductListing(ResourceResolver resourceResolver,
			PageContext pageContext, Page currentPage, ValueMap properties) {

			try {
				  int noOfProducts = 12;
				  String strCMSLinkText = properties.get("linkdispcopy", "");
				  String truncateCharValue = properties.get("truncatechar", "0"); ;
				  String rootPath = IntelUtil.getRootPath(currentPage);
				  if(rootPath != null && rootPath.length()!=0) {
					  rootPath = resourceResolver.map(rootPath);
				  } else {
					  rootPath = "";
				  }
				  String linkdispurl = properties.get("linkdispurl", "");
				  linkdispurl = linkdispurl.trim();
				  if(linkdispurl != null && linkdispurl.length()!=0) {
					  linkdispurl = resourceResolver.map(linkdispurl);
				  } else {
					  linkdispurl = "";
				  }
				  
				  int truncValue = Integer.parseInt(truncateCharValue);
				  strCMSLinkText = strCMSLinkText.trim();
				  if(strCMSLinkText.length() > truncValue && truncValue != 0 ){				      
				      strCMSLinkText = strCMSLinkText.substring(0,truncValue).concat("...");
				  }
				  if(strCMSLinkText.length() > 0) {
					  noOfProducts = 11;
				  }
				  pageContext.setAttribute("currentPageTitle",currentPage.getTitle());
				  pageContext.setAttribute("currentPageName",currentPage.getName());
				  pageContext.setAttribute("currentPagePath",resourceResolver.map(currentPage.getPath()));
				  pageContext.setAttribute("rootPath",rootPath);
				  pageContext.setAttribute("cmsTileUrl",linkdispurl);
				  pageContext.setAttribute("cmsTileImage",properties.get("imgFileReference", ""));
				  pageContext.setAttribute("cmsTileText",strCMSLinkText.trim());
				  pageContext.setAttribute("productnameMeta",IntelMobileConstants.META_TAG_FILTER_PRODUCT_NAME);
				  pageContext.setAttribute("priceMeta",IntelMobileConstants.META_TAG_FILTER_PRICE);
				  pageContext.setAttribute("pictureurlMeta",IntelMobileConstants.META_TAG_FILTER_PICTURE_URL);
				  pageContext.setAttribute("taglineMeta",IntelMobileConstants.META_TAG_FILTER_TAG_LINE);
				  pageContext.setAttribute("productpathMeta",IntelMobileConstants.META_TAG_PRODUCT_PATH);
				  pageContext.setAttribute("productidMeta",IntelMobileConstants.META_TAG_FILTER_PRODUCT_ID);
				  pageContext.setAttribute("prodListTitle",properties.get("prodlisttitle", "Introducing"));
				  pageContext.setAttribute("noOfProducts",noOfProducts);
				
				  String category = currentPage.getName();
				  Map<String,Object> results = getProductListing(category, noOfProducts,currentPage,pageContext);
				  pageContext.setAttribute("results", results);				
			} catch(Exception e) {
				LOGGER.error("[processProductListing] Exception occurred - ",e);
			}
	}
	
	public static Map<String, Object> getProductListing(String product,
			int noOfProducts, Page currentPage, PageContext pageContext) {
		Map<String, Object> results = new HashMap<String, Object>();

		results.put("totalCount", null);
		results.put("results", "0");

		try {
			StringBuffer searchUrlString = new StringBuffer();
			searchUrlString.append("http://216.255.85.96/presto/edge/api/rest/Intel_Mobile_POC_2/Invoke?x-presto-resultFormat=json&sortField=manufacturer&sortOrder=ascending&manufacturerFilter=&nameFilter=&osFilter=&processorFilter=&priceFilter=All&screenFilter=All&x-p-anonymous=true");
			LOGGER.info("searchUrlString :" + searchUrlString.toString());
			URL searchUrl = new URL(searchUrlString.toString());
			InputStream resultsStream = searchUrl.openStream();

			String jsonTxt = IOUtils.toString(resultsStream, "UTF-8");
			// LOGGER.info("---jsonTxt ---"+jsonTxt);
			JSONObject json = new JSONObject(jsonTxt);
			//String totalResults = json.getString("TotalCount");
			
			List<Map<String, String>> resultsList = new ArrayList<Map<String, String>>();
			JSONObject products=json.getJSONObject("products");
			JSONArray productArray=products.getJSONArray("product");
			int i = 0;
				for (; i < productArray.length(); i++) {
					
					Map<String, String> item = new HashMap<String, String>();
					
					JSONObject productInfo=productArray.getJSONObject(i);
					
					if(i>11)
						continue;
					String productName=productInfo.has("name")?productInfo.getString("name"):"";
					item.put("productName",productName);
					item.put(IntelMobileConstants.META_TAG_FILTER_SCREEN_SIZE,productInfo.has("screen")?productInfo.getString("screen"):"");
					item.put(IntelMobileConstants.META_TAG_FILTER_WEIGHT,productInfo.has("weight")?productInfo.getString("weight"):"");
					if(productInfo.has("processor")&&productInfo.getString("processor").contains("content"))
					{
						String content=productInfo.getJSONObject("processor").getString("content");
						item.put(IntelMobileConstants.META_TAG_FILTER_PROCESSOR,content.substring(content.indexOf("[")+1, content.lastIndexOf("]")).replaceAll("\"", ""));
					}
					else
					{	
						item.put(IntelMobileConstants.META_TAG_FILTER_PROCESSOR,productInfo.has("processor")?productInfo.getString("processor"):"");
					}
					item.put(IntelMobileConstants.META_TAG_FILTER_RAM,productInfo.has("ram")?productInfo.getString("ram"):"");
					item.put(IntelMobileConstants.META_TAG_FILTER_PRICE,productInfo.has("price")?productInfo.getString("price"):"");
					item.put(IntelMobileConstants.META_TAG_FILTER_MANUFACTURER,productInfo.has("manufacturer")?productInfo.getString("manufacturer"):"");
					item.put(IntelMobileConstants.META_TAG_FILTER_OPERATING_SYSTEM,productInfo.has("os")?productInfo.getString("os"):"");
					item.put("product", "ultrabooks");
					
					// LOGGER.info("---item---"+item);
					String productPath=productInfo.has("Path")?productInfo.getString("Path"):"";
					item.put("productUrl", productPath+".html");
					item.put("productId", productPath.substring(productPath.lastIndexOf("/")+1));
					item.put("productPath",productPath);
					resultsList.add(item);
				
				}
			results.put("totalCount", i);
			results.put("results", resultsList);
			results.put("json", jsonTxt);
		} catch (Exception e) {
			LOGGER.error("[getProductListing] Error Occurred - ", e);
		}

		return results;
	}
	public static void processSortFilter(ResourceResolver resourceResolver,
			PageContext pageContext, Page currentPage, ValueMap properties,Session jcrSession) {
		try {
		    IntelConfigurationService intelConfig = IntelUtil.getIntelConfigService();
		    
			ValueMap valueMap = currentPage.getProperties();
			String templateType = valueMap.get("cq:template",String.class);
			
			String section = "search";
			String category = "";
			if(templateType!= null 
					&& templateType.endsWith("/productlisting")) { 
				section = "products";
				category = currentPage.getName();
			}

			Map<String, Map<String, String>> filters = 
		    	FilterSortUtil.getProductFilters(resourceResolver, currentPage, section, category);
            //LOGGER.info("Filter List:" + filters);
            
			Map<String, String> sortoptions = 
				FilterSortUtil.getProductSortOptions(resourceResolver, currentPage, section, category);
			List<String> filtermasterlist=FilterSortUtil.getFilterList(category);
		 	
			
			String localecode = IntelUtil.getLocale(currentPage);
		 	
		 	String showhide = properties.get("showhide", "showboth");
		 	pageContext.setAttribute("masterlist", category);
			pageContext.setAttribute("jackbeUrl",/*intelConfig.getJackbeUrl()*/"http://216.255.85.96/presto/edge/api/rest/");
			pageContext.setAttribute("fastSearchAppId",intelConfig.getFastSearchAppId());
		 	pageContext.setAttribute("localecode", localecode);
		 	pageContext.setAttribute("category", category);
		 	pageContext.setAttribute("categoryMeta", IntelMobileConstants.META_TAG_FILTER_CATEGORY);
		 	pageContext.setAttribute("pagetypeMeta", IntelMobileConstants.META_TAG_FILTER_PAGETYPE);
		 	pageContext.setAttribute("localecodeMeta", IntelMobileConstants.META_TAG_LOCALE_CODE);
		 	pageContext.setAttribute("section", section);
			pageContext.setAttribute("filters", filters);
			pageContext.setAttribute("sortoptions", sortoptions);	
			pageContext.setAttribute("showhide", showhide);
		} catch(Exception e) {
			LOGGER.error("[processSortFilter] Exception occurred - ",e);
		}
	}
}
