package com.intel.mobile.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class ServiceClass {

	public String myCachedService(){
		
		ApplicationContext context= new FileSystemXmlApplicationContext("D:/UHC/workspace/spring-osgi/src/main/resources/META-INF/spring/applicationContext.xml");
		
		IHelloWorld obj=(IHelloWorld) context.getBean("iHelloWorld");
		try {
			obj.getList(101,new PrintWriter(new File("a.txt")));
			obj.getList(102,new PrintWriter(new File("a.txt")));
			obj.getList(101,new PrintWriter(new File("a.txt")));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "Hello Printed";
	}
	
}
