package com.intel.mobile.services;

import java.util.List;
import java.util.Map;

import com.intel.mobile.vo.MonitorDetailsVO;
import com.intel.mobile.vo.ProductVO;

/**
 * 
 * @author ujverm
 *
 */
public interface NotificationService {
	public void notifyErrorMessages(List<String> messages, String service) ;
	
	public void notifySuccessMessages(List<String> messages, String service) ;
   
	public void  productbatchMail( Map<String, List<ProductVO>> productlist);
    
	public void productErrorMail(String message);

	public void QueryErrorMail(String string);

    public void productmonitorMail(Map<String,List<MonitorDetailsVO>> monitorDetails);
}
