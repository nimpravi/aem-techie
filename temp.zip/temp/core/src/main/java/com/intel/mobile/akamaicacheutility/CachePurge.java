package com.intel.mobile.akamaicacheutility;



import javax.jcr.Session;

import org.apache.axis.AxisProperties;
import org.apache.commons.codec.binary.Base64;
import org.apache.sling.api.resource.Resource;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.intel.mobile.services.IntelConfigurationService;

public class CachePurge {
	private static final Logger log = LoggerFactory.getLogger(CachePurge.class);
	public static final String AKAMAI_CONFIG_NODE_PATH = "/etc/properties/akamaicache";
	public static final String GEOHOST_CONFIG_NODE_PATH = "/etc/properties/geohost";
	private String username = "";
	private String password = "";
	private String domain = "";
	private String endpointurl = "";
	private String emailadmin = "";
	private String purgequeue = "";
	private String proxyHost = "";
	private String proxyPort = "";
	private boolean emailNotification = false;
	private Resource resource = null;

	public void initConfiguration() {
		try {
			//this.resource = resource;
			BundleContext bundleContext = FrameworkUtil.getBundle(IntelConfigurationService.class).getBundleContext();  
			IntelConfigurationService intelConfigService = (IntelConfigurationService) bundleContext.getService(bundleContext.getServiceReference(IntelConfigurationService.class.getName()));	

			String endpointurl = intelConfigService.getAkamaiEndPointUrl();
			String emailadmin = intelConfigService.getEmailIdAkamaiNotification();
			String username = intelConfigService.getAkamaiUserId();
			String password = intelConfigService.getAkamaiPassword();
			String domain = intelConfigService.getAkamaiDomain();
			String purgequeue = "purgequeue";
			String proxyPort = "proxyPort";
			String proxyHost = "proxyHost";
			boolean emailNotification = intelConfigService.isEnableAkamaiNotification();

			this.setEndPointURL(endpointurl);
			this.setEmailAdmin(emailadmin);
			this.setUserName(username);
			//this.setPassword(this.decodeBase64(password));
			this.setPassword(password);
			this.setDomain(domain);
			this.setPurgeQueue(purgequeue);
			this.setProxyHost(proxyHost);
			this.setProxyPort(proxyPort);
			this.setEmailNotification((new Boolean(emailNotification)).booleanValue());

		} catch (Exception e) {
			log.info("Exception Occurred while initializing the properties:: " + e.getMessage());
		}
	}


	/**
	 * This method will call the Akamai Web Service and purge the cache.
	 * @param object_name
	 * @param content_Path
	 * @param type
	 * @param cacheUrl
	 * @throws Exception
	 */
	public PurgeResult PurgeAkamaiCache() throws Exception
	{
		log.info("Begin Purging...");
		String[] arrURLs = this.getPurgeQueue().split(";");
		PurgeApiProxy purgeProxy = new PurgeApiProxy(this.getEndPointURL());
		String[] strOptions = new String[4];
		strOptions[0] = "type=arl";
		strOptions[1] = "action=remove";
		strOptions[2] = "email-notification=" + this.getEmailAdmin();
		strOptions[3] = "domain=" + this.getDomain(); //staging or production
		PurgeResult pr =  purgeProxy.purgeRequest(this.getUserName(), this.getPassword(), "", strOptions, arrURLs);
		this.clearPurgeQueue();
		log.info(pr.getResultMsg());
		return pr;
	}

	public String purgeAkamaiCache(String url) throws Exception
	{
		log.info("Begin Purging akamai cache");
		String[] arrURLs = url.split(";");
		log.info("No. of URLs to be purged "+arrURLs.length);

		String[] strOptions = new String[4];
		strOptions[0] = "type=arl";
		strOptions[1] = "action=remove";
		strOptions[2] = "domain=" + this.getDomain(); //staging or production

		if(this.isEmailNotification())
			strOptions[3] = "email-notification=" + this.getEmailAdmin();
		try
		{
			//AxisProperties.setProperty("https.proxyHost", this.proxyHost);
			//AxisProperties.setProperty("https.proxyPort", this.proxyPort);
			log.info("End Point URL :"+this.getEndPointURL());
			log.info("Username :"+this.getUserName());
			log.info("Password :"+this.getPassword());

			PurgeApiProxy purgeProxy = new PurgeApiProxy(this.getEndPointURL());
			log.info(" eMail notification flag set to "+this.isEmailNotification());
			if(this.isEmailNotification()){
				log.info("Parameters Set: " + strOptions[0] + " , " + strOptions[1] + " , " + strOptions[2] +" , " + strOptions[3]);
			}else{
				log.info("Parameters Set: " + strOptions[0] + " , " + strOptions[1] + " , " + strOptions[2] );
			}
			PurgeResult pr =  purgeProxy.purgeRequest(this.getUserName(), this.getPassword(), "", strOptions, arrURLs);
			log.info(" Response from Akamai :: "+ pr.getResultCode() + " -- " +pr.getResultMsg());	        
			if(100 == pr.getResultCode()){
				log.info(" Estimated time to complete the request in seconds :: " +pr.getEstTime());
				return "SUCCESS";  
			}else{
				return pr.getResultMsg();
			}

		}
		catch (Exception e) {
			log.error("Got excetion  in PurgeAkamai "+e.getMessage());
			log.error(e.getMessage(), e);
			throw e;
		}
	}



	public String getEndPointURL() {
		return this.endpointurl;
	}

	public void setEndPointURL(String name) {
		this.endpointurl = name;
	}

	public String getUserName() {
		return this.username;
	}

	public void setUserName(String name) {
		this.username = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String name) {
		this.password = name;
	}

	public String getDomain() {
		return this.domain;
	}

	public void setDomain(String name) {
		this.domain = name;
	}

	public String getPurgeQueue() {
		return this.purgequeue;
	}

	public String getProxyHost() {
		return proxyHost;
	}

	public void setProxyHost(String proxyHost) {
		this.proxyHost = proxyHost;
	}

	public String getProxyPort() {
		return proxyPort;
	}

	public boolean isEmailNotification() {
		return emailNotification;
	}

	public void setEmailNotification(boolean emailNotification) {
		this.emailNotification = emailNotification;
	}

	public void setProxyPort(String proxyPort) {
		this.proxyPort = proxyPort;
	}

	public void setPurgeQueue(String name) {
		this.purgequeue = name;
	}

	public void clearPurgeQueue() {
		this.purgequeue = "";
		try {
			javax.jcr.Node purgeConfigNode = this.resource.getResourceResolver()
			.getResource(AKAMAI_CONFIG_NODE_PATH).adaptTo(
					javax.jcr.Node.class);

			Session session = purgeConfigNode.setProperty("purgequeue", "").getSession();
			log.info(" -- Akamai purge successful");
			session.save();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*  public void appendToPurgeQueue(String name) {
        try {
            javax.jcr.Node purgeConfigNode = this.resource.getResourceResolver().getResource(AKAMAI_CONFIG_NODE_PATH).adaptTo(javax.jcr.Node.class);
            javax.jcr.Node geoConfigNode = this.resource.getResourceResolver().getResource(GEOHOST_CONFIG_NODE_PATH).adaptTo(javax.jcr.Node.class);
            String pageLocale = ReImagineUtil.getLocale(name);  //TODO can this be replaced with a call to something like getLocaleCode instead?  If so the outdated, difficult-to-maintain getLocale method can be eliminated
            String pl = "www.intel.com";
            if(geoConfigNode.hasProperty(pageLocale)){
            	pl = geoConfigNode.getProperty(pageLocale).getValue().getString();
            }
            name = name.replaceAll("www.intel.com", pl);
            if(this.getPurgeQueue().isEmpty()) {
                Session session = purgeConfigNode.setProperty("purgequeue", name).getSession();
                session.save();
                session.logout();
                this.purgequeue = name;
            }
            else {
                this.purgequeue += ";" + name;
                Session session = purgeConfigNode.setProperty("purgequeue", this.purgequeue).getSession();
                session.save();
                session.logout();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }*/


	public String getEmailAdmin() {
		return this.emailadmin;
	}

	public void setEmailAdmin(String name) {
		this.emailadmin = name;
	}
	private String decodeBase64(String encodedValue)
	{
		byte[] decoded = Base64.decodeBase64(encodedValue.getBytes());
		String decodedString = new String(decoded);
		return decodedString;
	}
}
