package com.intel.mobile.shopmonitorservice;

import java.util.Dictionary;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.jcr.resource.JcrResourceResolverFactory;
import org.apache.sling.settings.SlingSettingsService;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.FrameworkUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.intel.mobile.services.impl.ShopNodeMonitorServiceImpl;
import com.intel.mobile.constants.IntelMobileConstants;
import com.intel.mobile.services.NotificationService;
import com.intel.mobile.services.impl.ShopSchedulerServiceImpl;
import com.intel.mobile.util.RepoUtil;
import com.intel.mobile.vo.MonitorDetailsVO;
/**
 * @author ggoswa
 *
 */

@Component (immediate=true, label="Intel Shop Node Monitor Scheduler", description = " Intel Shop Node Monitor Scheduler", metatype=true )
@Service 
@Properties({
	@Property(name = Constants.SERVICE_DESCRIPTION, value = "Intel Scheduler Service"),
	@Property(name = Constants.SERVICE_VENDOR, value = "Intel"),
	//@Property(name = "run.modes", value="author", cardinality = 2),
	@Property(name = "scheduler.concurrent",  boolValue=false),
	@Property(name = "scheduler.expression", value = "0 0 */12 * * ?" , description = "Scheduler Cron Expression. Follow the link http://www.docjar.com/docs/api/org/quartz/CronExpression.html for more details.")})


public class ShopNodeMonitorScheduler implements Runnable{
	private static final Logger LOG = LoggerFactory.getLogger(ShopNodeMonitorScheduler.class);

	@Reference
	private JcrResourceResolverFactory resourceResolverFactory;
	@Reference
	private SlingRepository repository;
	@Reference
	private NotificationService notificationService;
	@Property(label = "The Shop Node Monitor window", value = "10", description = "The range  to be used for shop node monitoring ")
	public static final String MONITOR_WINDOW = "monitorWindow";
	private Session jcrSession;
	private String window;



	protected void activate(ComponentContext context){
		try {
			LOG.info("activate method called");
			Dictionary props = context.getProperties();

			window = (String) props.get(MONITOR_WINDOW);

		} catch (Exception e){
			LOG.error(e.getMessage(), e);
		}
	}

	public void run(){
		LOG.info("Status :Inside run");

		try{
			BundleContext bundleContext = FrameworkUtil.getBundle(SlingSettingsService.class).getBundleContext();  
			SlingSettingsService slingSettingsService = (SlingSettingsService) bundleContext.getService(bundleContext.getServiceReference(SlingSettingsService.class.getName()));	
			//NotificationService notificationService = (NotificationService) bundleContext.getService(bundleContext.getServiceReference(NotificationService.class.getName()));
			Set<String> runModes = slingSettingsService.getRunModes();
			LOG.info("Run Modes :"+runModes);
			if(runModes!=null && runModes.contains(IntelMobileConstants.RUN_MODE_PUBLISH)){
				LOG.info("repository :"+repository);
				jcrSession = RepoUtil.login(repository);
				final ResourceResolver resourceResolver = resourceResolverFactory.getResourceResolver(jcrSession);
				ShopNodeMonitorServiceImpl monitorservice=new ShopNodeMonitorServiceImpl();
				Map<String,List<MonitorDetailsVO>> monitormap=monitorservice.shopMonitor(jcrSession,window,resourceResolver);
				LOG.info("Monitor Map"+ monitormap);
				if(!monitormap.isEmpty()) {
					notificationService.productmonitorMail(monitormap);
				}
               jcrSession.logout();
               
			}	else{
				LOG.debug("The service will only run in publish mode.Skip the execution.");
			}

		}catch (PathNotFoundException e) {
			LOG.error("PathNotFoundException :"+e.getMessage());

		} catch (RepositoryException e) {
			LOG.error("RepositoryException :"+e.getMessage());

		} catch (Exception e) {
			LOG.error("Exception :"+e.getMessage());
		}
	}
}
