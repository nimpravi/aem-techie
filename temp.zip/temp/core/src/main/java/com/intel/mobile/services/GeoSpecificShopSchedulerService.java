package com.intel.mobile.services;

public interface GeoSpecificShopSchedulerService {

}
