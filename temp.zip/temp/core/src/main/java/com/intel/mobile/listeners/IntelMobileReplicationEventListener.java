package com.intel.mobile.listeners;


import java.util.Map;
import java.util.Calendar;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;

import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.jcr.ValueFactory;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.api.SlingRepository;
import org.apache.sling.jcr.resource.JcrResourceResolverFactory;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationAction;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.commons.ReferenceSearch;
import com.day.cq.wcm.commons.ReferenceSearch.Info;
import com.intel.mobile.akamaicacheutility.CachePurge;
import com.intel.mobile.constants.IntelMobileConstants;
import com.intel.mobile.util.IntelUtil;


/**
 * This is an example listener that listens for replication events and
 * logs a message.
 */

@Component (immediate = true, metatype = false, label = "Intel Replication Listener")
@Service(org.osgi.service.event.EventHandler.class)
@Properties ({ @Property(name = "event.topics", value = ReplicationAction.EVENT_TOPIC) })

public class IntelMobileReplicationEventListener implements EventHandler {


	@Reference
	private SlingRepository repository;

	@Reference
	private JcrResourceResolverFactory resourceResolverFactory;

	private Session jcrSession;

	private static final Logger LOG = LoggerFactory.getLogger(IntelMobileReplicationEventListener.class);

	public void handleEvent(Event event) {

		LOG.info("Handle Event method of IntelMobileReplicationEventListener called.");
		String domainName = IntelUtil.getIntelConfigService().getDefaultAkamaiEnabledSiteDomain();
		LOG.info("Domain Name Before :"+domainName);
		String urlsToPurge=null;
		final String eventType = (String) event.getProperty(ReplicationAction.PROPERTY_TYPE);
		final ReplicationAction action = ReplicationAction.fromEvent(event);
		String path = action.getPath();
		LOG.info("The resource path of the replicated page/asset :"+path);
		try {
			jcrSession = repository.loginAdministrative(null);
			final ResourceResolver resourceResolver = resourceResolverFactory.getResourceResolver(jcrSession);
			LOG.info("eventType :"+eventType);
			
			if(eventType!=null && eventType.equals("DEACTIVATE")){
				 
				 removeXmlData(path, resourceResolver,jcrSession);
			 }
			
			
			
			if(eventType!=null && eventType.equals("ACTIVATE")){
				if(path!=null && path.startsWith(IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH)){
                    
					getXmlData(path, resourceResolver,jcrSession);
					Resource resource = resourceResolver.getResource(path);
					LOG.info("resource :"+resource);
					Page page = resource.adaptTo(Page.class);
					Page localeConfigPage = page.getAbsoluteParent(3);
					Resource localeResource= localeConfigPage.getContentResource("locale");
					if(localeResource!=null){
						Node localeNode = localeResource.adaptTo(Node.class);
						if(localeNode.hasProperty("domname")){
							domainName = localeNode.getProperty("domname").getString();
						}	
					}
					urlsToPurge = getUrlsToPurge(path,domainName);
				}else if(path!=null && (path.startsWith(IntelMobileConstants.INTEL_DAM_ROOT_NODE_PATH) || path.startsWith(IntelMobileConstants.INTEL_DESIGN_ROOT_NODE_PATH))) {

					//Get Aseet URL for all the domains where the asset is used.
					urlsToPurge = getDesignOrDAMUrlsToPurge(path, resourceResolver,jcrSession);
				}

				LOG.info("domainName :"+domainName);
				LOG.info("urlsToPurge ::"+urlsToPurge);	

				if(urlsToPurge!=null && urlsToPurge.length()>1){
					CachePurge cp = new CachePurge();
					cp.initConfiguration();
					String status = cp.purgeAkamaiCache(urlsToPurge);
					if("SUCCESS".equals(status)){
						LOG.info(" Request to clear the page " +domainName+path+" is successful");
					}
					else{
						LOG.error(" Request to clear the page " +domainName+path+" is failed :: "+ status );
					}
				}
			}
		} catch (RepositoryException e) {
			LOG.error("RepositoryException :",e);
		} catch (Exception e) {
			LOG.error("Exception :",e);
		}finally{
			jcrSession.logout();
		}

	}

	private String getUrlsToPurge(String path,String domainName){
		StringBuffer urlsToPurge = new StringBuffer();
		if(path.startsWith(IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH)){
			path = path.replace(IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH, "");
			urlsToPurge.append(domainName).append(path).append(".html").append(";");
			urlsToPurge.append(domainName).append(path).append(".smart.html").append(";");
			urlsToPurge.append(domainName).append(path).append(".touch.html").append(";");
			urlsToPurge.append(domainName).append(path).append(".nomatch.html").append(";");
			urlsToPurge.append(domainName).append(path).append(".feature.html").append(";");
		}
		return urlsToPurge.toString();
	}

	private String getDesignOrDAMUrlsToPurge(String path,ResourceResolver resourceResolver, Session jcrSession){

		StringBuffer urlsToPurge = new StringBuffer();
		/* ReferenceSearch referenceSearch = new ReferenceSearch();
	    referenceSearch.setSearchRoot(IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH);
	    Map<String,Info>  searchInfo = referenceSearch.search(resourceResolver, path);
	    LOG.info("searchInfo :"+searchInfo);
	    for (ReferenceSearch.Info info: searchInfo.values()) {
	    	LOG.info("Linked pages :"+info.getPage().getPath()); 

	    }*/

		try {
			QueryManager queryManager = jcrSession.getWorkspace().getQueryManager();
			Query query = queryManager.createQuery("/jcr:root"+IntelMobileConstants.INTEL_CONTENT_ROOT_NODE_PATH+"/element(*,cq:Page)/element(*,cq:Page)/jcr:content/locale[@domname]",Query.XPATH);
			QueryResult results = query.execute();
			NodeIterator nodeIter = results.getNodes();
			while(nodeIter.hasNext()) {
				Node localeNode = nodeIter.nextNode();
				String domainName = localeNode.getProperty("domname").getString();
				urlsToPurge.append(domainName).append(path).append(";");
			}

		} catch (RepositoryException e) {
			LOG.error("RepositoryException :",e);
		}

		return urlsToPurge.toString();
	}
	
	private void getXmlData(String path,ResourceResolver resourceResolver, Session jcrSession){
		 try {
			 
			
		Node tempNode = resourceResolver.resolve(path).adaptTo(Node.class);
		Node jcrNode = tempNode.getNode("jcr:content");
		String defVal = "-";
		LOG.info("CATEGORY NODE---"+jcrNode.getProperty("cq:template").getString());
		 if(tempNode.getParent().getName().toLowerCase().equals("ultrabooks") && (jcrNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/productdetailscms"))){
		Node detailNode=tempNode.getNode("jcr:content/details");
		StringBuilder sb = new StringBuilder("<");
		sb.append("product");
        sb.append(">");
    	sb.append("<");
          sb.append("name");
          sb.append(">");
          if(detailNode.hasProperty("name")){
        	  sb.append(detailNode.getProperty("name").getString());
          }else{
        	  sb.append(defVal);
        }
          sb.append("</");
	      sb.append("name");
	      sb.append(">");
	      
	      sb.append("<");
          sb.append("path");
          sb.append(">");
          sb.append(tempNode.getPath());
          sb.append("</");
          sb.append("path");
          sb.append(">");
          
          sb.append("<");
          sb.append("manufacturer");
          sb.append(">");
          if(detailNode.hasProperty("manufacturer")){
        	  sb.append(detailNode.getProperty("manufacturer").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("manufacturer");
          sb.append(">");
          
          sb.append("<");
          sb.append("os");
          sb.append(">");
          if(detailNode.hasProperty("os")){
        	  sb.append(detailNode.getProperty("os").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("os");
          sb.append(">");
          
          sb.append("<");
          sb.append("price");
          sb.append(">");
          if(detailNode.hasProperty("price")){
        	  sb.append(detailNode.getProperty("price").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("price");
          sb.append(">");
          
          sb.append("<");
          sb.append("processor");
          sb.append(">");
          if(detailNode.hasProperty("processor")){
        	  sb.append(detailNode.getProperty("processor").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("processor");
          sb.append(">");
          
          sb.append("<");
          sb.append("ram");
          sb.append(">");
          if(detailNode.hasProperty("ram")){
        	  sb.append(detailNode.getProperty("ram").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("ram");
          sb.append(">");
          
          sb.append("<");
          sb.append("screen");
          sb.append(">");
          if(detailNode.hasProperty("screen")){
        	  sb.append(detailNode.getProperty("screen").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("screen");
          sb.append(">");
          
          sb.append("<");
          sb.append("weight");
          sb.append(">");
          if(detailNode.hasProperty("weight")){
        	  sb.append(detailNode.getProperty("weight").getString());
          }else{
        	  sb.append(defVal); 
          }
          sb.append("</");
          sb.append("weight");
          sb.append(">");
          
          if(detailNode.hasProperty("filterprocessor") && detailNode.getProperty("filterprocessor").isMultiple()){
          
          sb.append("<");
          sb.append("filterprocessorlist");
          sb.append(">");
          Value[] values=detailNode.getProperty("filterprocessor").getValues();
      	for(int i=0;i<values.length;i++)
			{
      		sb.append("<");
            sb.append("filterprocessor");
            sb.append(">");
            sb.append(values[i].getString());
            sb.append("</");
            sb.append("filterprocessor");
            sb.append(">");
			}
      		
      	sb.append("</");
        sb.append("filterprocessorlist");
        sb.append(">");
			}
       
          sb.append("<");
          sb.append("picture");
          sb.append(">");
          if(detailNode.hasProperty("picture")){
        	  sb.append(detailNode.getProperty("picture").getString());
              }else{
            	  sb.append(defVal); 
              }
          //detailNode.getProperty("picture").getString();
          sb.append("</");
          sb.append("picture");
          sb.append(">");
          sb.append("</");
          sb.append("product");
	      sb.append(">");
	      //LOG.info("====BUILD STRING === "+sb.toString());
	      String xmlpath = "/content/usergenerated/content/ultrabooks.xml";
	      Node newNode = resourceResolver.resolve(xmlpath).adaptTo(Node.class);
	      Node jcrNode1=newNode.getNode("jcr:content");
	      //LOG.info("====jcr node === "+jcrNode.toString());
	      Value value = jcrNode1.getProperty("jcr:data").getValue();
	      String contentvalue = value.getString();
	      //LOG.info("====Content value "+contentvalue);
	     // LOG.info("====Content value before --- "+contentvalue.substring(0,contentvalue.lastIndexOf("</products>")));
	      contentvalue =contentvalue.substring(0,contentvalue.lastIndexOf("</products>"))+ sb.toString()+"</products>";
	     // LOG.info("====Content value After --- "+contentvalue.substring(0,contentvalue.lastIndexOf("</products>")));
	      
	    String mimeType = "application/octet-stream";
	  	String uploadPath="/content/usergenerated/content";
	  	Node node=jcrSession.getNode(uploadPath);
	  	ValueFactory valueFactory = jcrSession.getValueFactory();
	  	Value conValue = valueFactory.createValue(contentvalue);
	  	Node fileNode;
	  	String filename="ultrabooks.xml";
	  	if(!node.hasNode(filename))
	  	fileNode = node.addNode(filename, "nt:file");
	  	else
	  	fileNode=jcrSession.getNode(uploadPath + "/" + filename);	
	  	LOG.info("Node added");
	  	fileNode.addMixin("mix:referenceable");
	  	Node resNode;
	  	if(!fileNode.hasNode("jcr:content"))
	  	resNode = fileNode.addNode("jcr:content", "nt:resource");
	  	else
	  	resNode = jcrSession.getNode(uploadPath + "/" + filename + "/" +  "jcr:content");	
	  	resNode.setProperty("jcr:mimeType", mimeType);
	  	resNode.setProperty("jcr:data", conValue);
	  	Calendar lastModified = Calendar.getInstance();
	  	lastModified.setTimeInMillis(lastModified.getTimeInMillis());
	  	resNode.setProperty("jcr:lastModified", lastModified);
	  	jcrSession.save();
	      
		 }
		 }
		 catch(RepositoryException e1){
			   LOG.info("Error in getXmlData: "+e1);
		 }
		  
	}
	private void removeXmlData(String path,ResourceResolver resourceResolver, Session jcrSession){
		LOG.info("Entered removeXmlData" );
		 try {
		  Node tempNode = resourceResolver.resolve(path).adaptTo(Node.class);
		  Node jcrNode = tempNode.getNode("jcr:content");
		  LOG.info("CATEGORY NODE---"+jcrNode.getProperty("cq:template").getString());
		  if(tempNode.getParent().getName().toLowerCase().equals("ultrabooks") && (jcrNode.getProperty("cq:template").getString().equals("/apps/intelmobile/templates/productdetailscms"))){
	       String xmlpath = "/content/usergenerated/content/ultrabooks.xml";
	       Node newNode = resourceResolver.resolve(xmlpath).adaptTo(Node.class);
	       Node jcrNode1=newNode.getNode("jcr:content");
           Value value = jcrNode1.getProperty("jcr:data").getValue();
	       String contentvalue = value.getString();
	       int index=contentvalue.indexOf("<Path>"+path+"</Path>");
	       if(index>0){
	    	   
	    	int startIndex=contentvalue.substring(0,index).lastIndexOf("<product><name>");
	    	int endIndex=contentvalue.indexOf("</product>",index);
	    	contentvalue=contentvalue.substring(0, startIndex).concat(contentvalue.substring(endIndex+10));
	    	String mimeType = "application/octet-stream";
		  	String uploadPath="/content/usergenerated/content";
		  	Node node=jcrSession.getNode(uploadPath);
		  	Node fileNode;
		  	String filename="ultrabooks.xml";
		  	if(!node.hasNode(filename))
		  	fileNode = node.addNode(filename, "nt:file");
		  	else
		  	fileNode=jcrSession.getNode(uploadPath + "/" + filename);	
		  	LOG.info("Node added");
		  	fileNode.addMixin("mix:referenceable");
		  	Node resNode;
		  	if(!fileNode.hasNode("jcr:content"))
		  	resNode = fileNode.addNode("jcr:content", "nt:resource");
		  	else
		  	resNode = jcrSession.getNode(uploadPath + "/" + filename + "/" +  "jcr:content");	
		  	resNode.setProperty("jcr:mimeType", mimeType);
		  	resNode.setProperty("jcr:data", contentvalue);
		  	Calendar lastModified = Calendar.getInstance();
		  	lastModified.setTimeInMillis(lastModified.getTimeInMillis());
		  	resNode.setProperty("jcr:lastModified", lastModified);
		  	jcrSession.save();
		  	LOG.info("Exiting removeXmlData" );
	       }
 	 
		 }
		  
		 }
		 catch(RepositoryException e1){
			   LOG.info("Error in removeXmlData: "+e1);
		 }
		  
	}
}
