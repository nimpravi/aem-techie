/**
 * 
 */
package com.intel.mobile.services;

/**
 * @author skarm1
 *
 */
public interface IntelConfigurationService {

	public String getApiKey();
	public void setApiKey(String apiKey);
	public String getIntelShopAPIUrl();
	public void setIntelShopAPIUrl(String intelShopAPIUrl);
	public String getPageSize();
	public void setPageSize(String pageSize);
	public String getArkApiUrl();
	public void setArkApiUrl(String arkProcessorApiUrl);
	public String getArkApiKey();
	public void setArkApiKey(String arkApiKey);	
	public boolean isSyncJobDisabled();
	public void setSyncJobDisabled(boolean disabled);
	public boolean isSyncImage();
	public void setSyncImage(boolean isSyncImage);

	public String getWapTrackingEnv();
	public void setWapTrackingEnv(String wapTrackingEnv);
    public void setFastSearchUrl(String fastSearchUrl);
	public void setFastSearchAppId(String fastSearchAppId);
	public String getFastSearchUrl();
	public String getFastSearchAppId();
	public String getSpecEmailBody();
	public void setSpecEmailBody(String specEmailBody);
	public String getSpecEmailSubject();
	public void setSpecEmailSubject(String specEmailSubject);
	
	public String getAkamaiEndPointUrl();
	public void setAkamaiEndPointUrl(String akamaiEndPointUrl);
	public String getAkamaiUserId();
	public void setAkamaiUserId(String akamaiUserId);
	public String getAkamaiPassword();
	public void setAkamaiPassword(String akamaiPassword);
	public String getAkamaiDomain();
	public void setAkamaiDomain(String akamaiDomain);
	public String getDefaultAkamaiEnabledSiteDomain();
	public boolean isEnableAkamaiNotification();
	public void setEnableAkamaiNotification(boolean enableAkamaiNotification);
	public String getEmailIdAkamaiNotification();
	public void setEmailIdAkamaiNotification(String emailIdAkamaiNotification);
	public void setDefaultAkamaiEnabledSiteDomain(String defaultAkamaiEnabledSiteDomain);

}
