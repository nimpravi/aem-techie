package com.intel.mobile.servlets;

import java.io.IOException;

import com.day.cq.dam.api.Asset;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * @author skarmakar
 *
 */

@Component(immediate = true, metatype = false, label = "Image Size Check Servlet")
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/imagesizecheck") })



public class ImageSizeCheckServlet extends SlingAllMethodsServlet{



	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ImageSizeCheckServlet.class);

	public void doPost(SlingHttpServletRequest request,
			SlingHttpServletResponse response) throws IOException {

	}
	protected void doGet(SlingHttpServletRequest request,SlingHttpServletResponse response) throws IOException {

		String imageType = request.getParameter("imageType");

		if(imageType!=null && imageType.equals("multi")){
			checkImageSizeOfMultipleImages(request, response);
		}else if(imageType!=null && imageType.equals("single")){
			checkImageSizeOfSingleImage(request, response);
		}

	}


	private void checkImageSizeOfMultipleImages(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException{

		String imagePaths[] = request.getParameter("imagePaths").split("\\|"); 
		LOGGER.info("imagePaths :"+imagePaths);
		String acceptableLength = request.getParameter("acceptableLength");
		String acceptableWidth = request.getParameter("acceptableWidth");
		String component = request.getParameter("component");
		String layoutType= request.getParameter("layoutType");
		final ResourceResolver resourceResolver = request.getResourceResolver();
		JSONObject jsonObject = new JSONObject();
		JSONArray failureMsgArray = new JSONArray();
		JSONArray successMsgArray = new JSONArray();
		/*Intel Reskin Image Size Validation checks start (multiple dimensions are separated by |)*/
		String[] accptableLengthArr=acceptableLength.contains("_")?acceptableLength.split("_"):null;
		String[] acceptableWidthArr=acceptableWidth.contains("_")?acceptableLength.split("_"):null;
		/*Intel Reskin Image Size Validation checks end*/
		for(int i=0;i<imagePaths.length;i++){
			String imagePath = imagePaths[i];
			LOGGER.info("imagePath :"+imagePath);
			Resource resource = resourceResolver.getResource(imagePath);
			Asset asset = resource.adaptTo(Asset.class);
			String imageLength = asset.getMetadataValue("tiff:ImageLength");
			String imageWidth = asset.getMetadataValue("tiff:ImageWidth");
			LOGGER.info("Asset Name :"+asset.getName());	 	 
			try{
				if(i==0 && component!=null && component.equals("herotiles") && layoutType!=null && layoutType.equals("layout2")){
					if(!"284".equals(imageLength) || !"610".equals(imageWidth)){
						JSONObject failure = new JSONObject();
						failure.put("name",asset.getName());
						failure.put("required", "610X284");
						failure.put("given", imageWidth+"X"+imageLength);
						failureMsgArray.put(failure);
						LOGGER.info(" failure :"+failure.toString());
					}
				}
				else if(i==0 && component!=null && component.equals("herotiles") && layoutType!=null && layoutType.equals("layout3")){
					LOGGER.info("---------- layoutType :"+layoutType);
					if(!"582".equals(imageLength) || !"640".equals(imageWidth)){
						JSONObject failure = new JSONObject();
						failure.put("name",asset.getName());
						failure.put("required", "610x582");
						failure.put("given", imageWidth+"X"+imageLength);
						failureMsgArray.put(failure);
						LOGGER.info(" failure :"+failure.toString());
					}
					
				}
				else if(i==0 && component!=null && component.equals("herotiles") && layoutType!=null && layoutType.equals("layout4")){
					if(!"305".equals(imageLength) || !"640".equals(imageWidth)){
						JSONObject failure = new JSONObject();
						failure.put("name",asset.getName());
						failure.put("required", "640X305");
						failure.put("given", imageWidth+"X"+imageLength);
						failureMsgArray.put(failure);
						LOGGER.info(" failure :"+failure.toString());
					}
					
				}
				else if((i==1 || i==4) && component!=null && component.equals("herotiles") && layoutType!=null && layoutType.equals("layout4")){
					if(!"257".equals(imageLength) || !"317".equals(imageWidth)){
						JSONObject failure = new JSONObject();
						failure.put("name",asset.getName());
						failure.put("required", "317X257");
						failure.put("given", imageWidth+"X"+imageLength);
						failureMsgArray.put(failure);
						LOGGER.info(" failure :"+failure.toString());
					}
					
				}
				else if((i==2 || i==3) && component!=null && component.equals("herotiles") && layoutType!=null && layoutType.equals("layout4")){
					if(!"520".equals(imageLength) || !"317".equals(imageWidth)){
						JSONObject failure = new JSONObject();
						failure.put("name",asset.getName());
						failure.put("required", "317X520");
						failure.put("given", imageWidth+"X"+imageLength);
						failureMsgArray.put(failure);
						LOGGER.info(" failure :"+failure.toString());
					}
					
				}
				else if(i==5 && component!=null && component.equals("herotiles") && layoutType!=null && layoutType.equals("layout4")){
					if(!"257".equals(imageLength) || !"640".equals(imageWidth)){
						JSONObject failure = new JSONObject();
						failure.put("name",asset.getName());
						failure.put("required", "640X257");
						failure.put("given", imageWidth+"X"+imageLength);
						failureMsgArray.put(failure);
						LOGGER.info(" failure :"+failure.toString());
					}
					
				}
				else{
					
					if(accptableLengthArr==null && acceptableWidthArr==null)
					{
						if(!acceptableLength.equals(imageLength) || !acceptableWidth.equals(imageWidth) ){
							JSONObject failure = new JSONObject();
							failure.put("name",asset.getName());
							failure.put("required", acceptableWidth+"X"+acceptableLength);
							failure.put("given", imageWidth+"X"+imageLength);
							failureMsgArray.put(failure);
							LOGGER.info(" failure :"+failure.toString());
						}
						else{
							JSONObject success = new JSONObject();
							success.put("required", acceptableWidth+"X"+acceptableLength);
							success.put("given", imageWidth+"X"+imageLength);
							successMsgArray.put(success);
							LOGGER.info(" success :"+success.toString());
						}
					}
					else if(accptableLengthArr!=null && acceptableWidthArr==null)
					{
						boolean failureFlag=false;
						for (String string : accptableLengthArr) {
							
							if(!string.equals(imageLength) || !acceptableWidth.equals(imageWidth) ){
								failureFlag=true;
							}
							else
							{
								failureFlag=false;
								break;
							}
						}
						if(failureFlag)
						{
							JSONObject failure = new JSONObject();
							failure.put("name",asset.getName());
							String requiredString="";
							for (int counter=0;counter<accptableLengthArr.length;counter++) {
								
								if(counter==0)
									requiredString=accptableLengthArr[counter]+"X"+acceptableWidth+" or ";
								else if(counter+1==accptableLengthArr.length)
									requiredString+=accptableLengthArr[counter]+"X"+acceptableWidth;
								else
									requiredString+=accptableLengthArr[counter]+"X"+acceptableWidth+" or ";
							}
							failure.put("required", requiredString);
							failure.put("given", imageWidth+"X"+imageLength);
							failureMsgArray.put(failure);
							LOGGER.info(" failure :"+failure.toString());
						}
						else
						{
							JSONObject success = new JSONObject();
							success.put("required", acceptableWidth+"X"+acceptableLength);
							success.put("given", imageWidth+"X"+imageLength);
							successMsgArray.put(success);
							LOGGER.info(" success :"+success.toString());
						}
							
					}
					
					else if(accptableLengthArr==null && acceptableWidthArr!=null)
					{
						boolean failureFlag=false;
						for (String string : acceptableWidthArr) {
							
							if(!acceptableLength.equals(imageLength) || !string.equals(imageWidth) ){
								failureFlag=true;
							}
							else
							{
								failureFlag=false;
								break;
							}
						}
						if(failureFlag)
						{
							JSONObject failure = new JSONObject();
							failure.put("name",asset.getName());
							String requiredString="";
							for (int counter=0;counter<accptableLengthArr.length;counter++) {
								
								if(counter==0)
									requiredString=acceptableLength+"X"+acceptableWidthArr[counter]+" or ";
								else if(counter+1==accptableLengthArr.length)
									requiredString+=acceptableLength+"X"+acceptableWidthArr[counter];
								else
									requiredString+=acceptableLength+"X"+acceptableWidthArr[counter]+" or ";
							}
							failure.put("required", requiredString);
							failure.put("given", imageWidth+"X"+imageLength);
							failureMsgArray.put(failure);
							LOGGER.info(" failure :"+failure.toString());
						}
						else
						{
							JSONObject success = new JSONObject();
							success.put("required", acceptableWidth+"X"+acceptableLength);
							success.put("given", imageWidth+"X"+imageLength);
							successMsgArray.put(success);
							LOGGER.info(" success :"+success.toString());
						}
							
					}
					else{
						boolean failureFlag=false;
						for (String string : acceptableWidthArr) {
							for (String string1 : accptableLengthArr) {
								
								if(!string1.equals(imageLength) || !string.equals(imageWidth) ){
									failureFlag=true;
								}
								else
								{
									failureFlag=false;
									break;
								}
								
							}
							
						}
						if(failureFlag)
						{
							JSONObject failure = new JSONObject();
							failure.put("name",asset.getName());
							String requiredString="";
							for (int counter=0;counter<accptableLengthArr.length;counter++) {
								for(int counter1=0;counter1<accptableLengthArr.length;counter1++)
								{
									if(counter==0)
										requiredString=accptableLengthArr[counter]+"X"+acceptableWidthArr[counter1]+" or ";
									else if(counter+1==accptableLengthArr.length)
										requiredString+=accptableLengthArr[counter]+"X"+acceptableWidthArr[counter1];
									else
										requiredString+=accptableLengthArr[counter]+"X"+acceptableWidthArr[counter1]+" or ";
								}
							}
							failure.put("required", requiredString);
							failure.put("given", imageWidth+"X"+imageLength);
							failureMsgArray.put(failure);
							LOGGER.info(" failure :"+failure.toString());
						}
						else
						{
							JSONObject success = new JSONObject();
							success.put("required", acceptableWidth+"X"+acceptableLength);
							success.put("given", imageWidth+"X"+imageLength);
							successMsgArray.put(success);
							LOGGER.info(" success :"+success.toString());
						}
						
					}
					
				}
				
					

				if(failureMsgArray.length() >0){
					jsonObject.put("result", "failed");
					jsonObject.put("message", failureMsgArray);
				}else {
					jsonObject.put("result", "success");
					jsonObject.put("message", successMsgArray);
				}			
			}catch (JSONException e){
				LOGGER.error("JSONException :"+e.getMessage());
			}
		}

		LOGGER.info(" JSON :"+jsonObject.toString());
		response.setContentType("application/json;charset=utf-8");
		response.getWriter().write(jsonObject.toString());

	}

	private void checkImageSizeOfSingleImage(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException{

		String imagePath = request.getParameter("imagePath");
		LOGGER.info("imagePath :"+imagePath);
		String acceptableLength = request.getParameter("acceptableLength");
		String acceptableWidth = request.getParameter("acceptableWidth");
		LOGGER.info("acceptableLength :"+acceptableLength);
		LOGGER.info("acceptableWidth :"+acceptableWidth);
		final ResourceResolver resourceResolver = request.getResourceResolver();
		Resource resource = resourceResolver.getResource(imagePath);
		Asset asset = resource.adaptTo(Asset.class);
		String imageLength = asset.getMetadataValue("tiff:ImageLength");
		String imageWidth = asset.getMetadataValue("tiff:ImageWidth");
		LOGGER.info("Asset Name :"+asset.getName());	 	 
		LOGGER.info("imageLength :"+imageLength);
		LOGGER.info("imageWidth :"+imageWidth);
		JSONObject jsonObject = new JSONObject();
		response.setContentType("application/json;charset=utf-8");
		/*Intel Reskin Image Size Validation checks start (multiple dimensions are separated by |)*/
		String[] accptableLengthArr=acceptableLength.contains("_")?acceptableLength.split("_"):null;
		String[] acceptableWidthArr=acceptableWidth.contains("_")?acceptableWidth.split("_"):null;
		LOGGER.info("accptableLengthArr :"+accptableLengthArr.length);
		LOGGER.info("acceptableWidthArr :"+acceptableWidthArr.length);
		/*Intel Reskin Image Size Validation checks end*/
		try{
			/*if(!acceptableLength.equals(imageLength) || !acceptableWidth.equals(imageWidth) ){
				jsonObject.put("result", "failed");
				JSONObject failure = new JSONObject();
				failure.put("name",asset.getName());
				failure.put("required", acceptableWidth+"X"+acceptableLength);
				failure.put("given", imageWidth+"X"+imageLength);
				jsonObject.put("message", failure);

			}else{}*/
			


			
			if(accptableLengthArr==null && acceptableWidthArr==null)
			{
				if(!acceptableLength.equals(imageLength) || !acceptableWidth.equals(imageWidth) ){
					jsonObject.put("result", "failed");
					JSONObject failure = new JSONObject();
					failure.put("name",asset.getName());
					failure.put("required", acceptableWidth+"X"+acceptableLength);
					failure.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", failure);
				}
				else{
					jsonObject.put("result", "success");
					JSONObject success = new JSONObject();
					success.put("name",asset.getName());
					success.put("required", acceptableWidth+"X"+acceptableLength);
					success.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", success);
				}
			}
			else if(accptableLengthArr!=null && acceptableWidthArr==null)
			{
				boolean failureFlag=false;
				for (String string : accptableLengthArr) {
					
					if(!string.equals(imageLength) || !acceptableWidth.equals(imageWidth) ){
						failureFlag=true;
					}
					else
					{
						failureFlag=false;
						break;
					}
				}
				if(failureFlag)
				{
					
					jsonObject.put("result", "failed");
					JSONObject failure = new JSONObject();
					failure.put("name",asset.getName());
					String requiredString="";
					for (int counter=0;counter<accptableLengthArr.length;counter++) {
						
						if(counter==0)
							requiredString=accptableLengthArr[counter]+"X"+acceptableWidth+" or ";
						else if(counter+1==accptableLengthArr.length)
							requiredString+=accptableLengthArr[counter]+"X"+acceptableWidth;
						else
							requiredString+=accptableLengthArr[counter]+"X"+acceptableWidth+" or ";
					}
					LOGGER.info("requiredString---:"+requiredString);
					failure.put("required", requiredString);
					failure.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", failure);
				}
				else
				{
					JSONObject success = new JSONObject();
					success.put("required", acceptableWidth+"X"+acceptableLength);
					success.put("given", imageWidth+"X"+imageLength);
					LOGGER.info(" success :"+success.toString());
				}
					
			}
			
			else if(accptableLengthArr==null && acceptableWidthArr!=null)
			{
				boolean failureFlag=false;
				for (String string : acceptableWidthArr) {
					
					if(!acceptableLength.equals(imageLength) || !string.equals(imageWidth) ){
						failureFlag=true;
					}
					else
					{
						failureFlag=false;
						break;
					}
				}
				if(failureFlag)
				{
					jsonObject.put("result", "failed");
					JSONObject failure = new JSONObject();
					failure.put("name",asset.getName());
					String requiredString="";
					for (int counter=0;counter<accptableLengthArr.length;counter++) {
						
						if(counter==0)
							requiredString=acceptableLength+"X"+acceptableWidthArr[counter]+" or ";
						else if(counter+1==accptableLengthArr.length)
							requiredString+=acceptableLength+"X"+acceptableWidthArr[counter];
						else
							requiredString+=acceptableLength+"X"+acceptableWidthArr[counter]+" or ";
					}
					failure.put("required", requiredString);
					failure.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", failure);
				}
				else
				{
					jsonObject.put("result", "success");
					JSONObject success = new JSONObject();
					success.put("name",asset.getName());
					success.put("required", acceptableWidth+"X"+acceptableLength);
					success.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", success);
				}
					
			}
			else{
				boolean failureFlag=true;
				for (String string : acceptableWidthArr) {
					for (String string1 : accptableLengthArr) {
						if(string1.equals(imageLength) && string.equals(imageWidth) ){
					          failureFlag=false;
						}
					}
					
				}
				if(failureFlag)
				{
					jsonObject.put("result", "failed");
					JSONObject failure = new JSONObject();
					failure.put("name",asset.getName());
					String requiredString="";
					for (int counter=0;counter<acceptableWidthArr.length;counter++) {
						for(int counter1=0;counter1<accptableLengthArr.length;counter1++)
						{
							if(counter==0 && counter1==0)
								requiredString=acceptableWidthArr[counter]+"X"+accptableLengthArr[counter1]+" or ";
							else if(counter1+1==accptableLengthArr.length && counter+1==acceptableWidthArr.length)
								requiredString+=acceptableWidthArr[counter]+"X"+accptableLengthArr[counter1];
							else
								requiredString+=acceptableWidthArr[counter]+"X"+accptableLengthArr[counter1]+" or ";
						}
					}
					failure.put("required", requiredString);
					failure.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", failure);
					LOGGER.info(" failure :"+failure.toString());
				}
				else
				{
					jsonObject.put("result", "success");
					JSONObject success = new JSONObject();
					success.put("name",asset.getName());
					success.put("required", acceptableWidth+"X"+acceptableLength);
					success.put("given", imageWidth+"X"+imageLength);
					jsonObject.put("message", success);
				}
				
			}
		
		}catch(JSONException e){
			LOGGER.error("JSONException :"+e.getMessage());
		}
		
		LOGGER.info(" JSON :"+jsonObject.toString());
		response.setContentType("application/json;charset=utf-8");
		response.getWriter().write(jsonObject.toString());

	}


}





