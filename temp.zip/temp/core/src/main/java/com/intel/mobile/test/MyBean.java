package com.intel.mobile.test;

import java.io.PrintWriter;

import org.springframework.stereotype.Component;

@Component
public class MyBean implements IMyBean {
	public void displayString(PrintWriter writer) {
		writer.println("Inside MyBean");
	}
}
