package com.intel.mobile.services;

public interface ShopNodeMonitorService {

}
